<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;


}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 40%;
}

div.card {
  padding: 15px;
  text-align: center;
}

div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.php" >

          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Máquinas de Secar</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 

        <div class="container" >
          <div class="row">

         
  <div class="card">
    <img class="card-img-top" src="ms1.jpg"  ">
    <div class="card-body">
      <h5 class="card-title" >Máquina Secar Roupa Candy 8KG CSOH8A2TES  </h5>
      <p class="card-text" >Máquina de secar roupa CSOH8A2TES, capacidade de 8 kg, eficiência energética A++.  Equipado com conexão NFC (Smart), também equipado com indicador digital de controlo de contagem regressiva, ajuste de temperatura de secagem e indicador de filtro entupido. Possui 15 programas e indicador de fim de ciclo. Esta Máquina de secar roupa apresenta um sistema de secagem por condensação com tecnologia de bomba de calor.</p>

    
    </div>
    <a href="li1.php" class="btn btn-primary">Ver Mais</a>
  </div>


  <div class="card" >
    <img class="card-img-top" src="ms2.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Secar Roupa Indesit 7KG YTM0871REU</h5>
      <p class="card-text">Máquina de secar roupa YTM0871REU, capacidade de 7 kg, eficiência energética A+ e 850 W de potência. Tecnologia inovadora que garante uma performance extra silenciosa.A cesta de sapatos é o acessório perfeito para o teu secador Indesit, permitindo secar rápida e facilmente os teus ténis favoritos.O programa Easy Mix foi desenvolvido para uma secagem eficaz de até 3 kg de tecidos misturados, o que evita a necessidade de lavar tudo separadamente.</p>
      
      
    </div>
     <a href="li2.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="ms3.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Secar Roupa Candy 9KG RO H9A3TSEX-S</h5>
      <p class="card-text">Máquina de secar roupa RO H9A3TSEX-S, capacidade de 9 kg, eficiência energética A+++.  Equipado com conexão NFC (Smart), também equipado com indicador digital de controlo de contagem regressiva, ajuste de temperatura de secagem e indicador de filtro entupido. Possui 15 programas e indicador de fim de ciclo. Esta Máquina de secar roupa apresenta um sistema de secagem por condensação com tecnologia de bomba de calor.</p>
      
        
    </div>
     <a href="li3.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >


      <div class="row">
   <div class="card">
    <img class="card-img-top" src="ms4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Secar Roupa Hotpoint-Ariston NT-CM10-8B-EU</h5>
Máquina de secar roupa NT-CM10-8B-EU da Hotpoint-Ariston, capacidade de 8 kg, eficiência energética B e 2700 W de potência.Um programa de 20 minutos para roupas secas que as mantém arejadas e frescas, eliminando odores desagradáveis com este programa.Uma solução inovadora de limpeza, um filtro condensador mais pequeno e leve que pode ser facilmente limpo e de forma mais rápida.
    </div>
     <a href="li4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="ms5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Secar Roupa Jocel JSR013972</h5>
      <p class="card-text">Com 7 kg de carga máxima de secagem e 15 programas de secagem, tens várias opções para escolher o programa conveniente ou aquele que vai ao encontro das características da sua roupa. Bloqueio para crianças,  emissão de ruído de 68dB, Potência 2350W.</p>
      
      
    </div>
     <a href="li5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="ms6.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Secar Roupa Indesit IDV 75 </h5>
      <p class="card-text">Com 7 kg de carga máxima de secagem e 12+1 programas de secagem, tens várias opções para escolher o programa conveniente ou aquele que vai ao encontro das características da sua roupa. Em cerca de 109 minutos e com emissão de ruído de 69dB a secagem será feita com eficácia.</p.>
      
        
    </div>
     <a href="li6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >
       <div class="row">
  <div class="card" >
    <img class="card-img-top" src="ms7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Secar Roupa Samsung DV90N62632W</h5>
      <p class="card-text">
     
 Máquina de secar a roupa, em branco da SAMSUNG. Classe de eficiência A+++ e capacidade de carga de 9 Kg. Processo de secagem através de bomba de calor. Display LED, Smart Control, luz no interior do tambor e porta reversível. Filtro 2 em 1, 3 níveis de secagem e controlo via Wifi. A DV90N62632W dispõe ainda de Smart Check (verificação de erros).
</p>
      
      
    </div>

     <a href="li7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="ms8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Secar Roupa Hotpoint-Ariston NTM1182SK  </h5>
      <p class="card-text">Máquina de secar roupa NTM1182SK da Hotpoint-Ariston, capacidade de 8 kg, eficiência energética A++ e 850 W de potência.O motor inverter permite um ciclo de secagem silencioso, com desempenho superior e alta eficiência energética.A inovadora tecnologia activecare reduz os danos dos tecidos em 40%, ao minimizar a tensão nas roupas, para que possas desfrutar delas durante mais tempo, até 40% com base no programa jeans sem activecare.Uma solução inovadora de limpeza, um filtro condensador mais pequeno e leve que pode ser facilmente limpo e de forma mais rápida.

</p>
      
      
      
    </div>
     <a href="li8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="ms9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar e Secar Roupa Silver IPMLSA 8/5 Kg 1400RPM</h5>
      <p class="card-text"> Máquina lavar e secar roupa Silver IPMLSA com uma capacidade de carga para lavagem de 8Kg e para secagem de 5Kg, classe energética A+++, a máquina de lavar e secar Silver IPMLSA carateriza-se ainda pela sua velocidade máxima de centrifugação de 1400 RPM.Dispõe também de sistema de bloqueio de segurança para crianças, 16 programas destaque para o programa rápido e o modo económico. 
    </div>
     <a href="li9.php" class="btn btn-primary">Ver
      Mais</a>
  </div>

</div>

                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos liui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>