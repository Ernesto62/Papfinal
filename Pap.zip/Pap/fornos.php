<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;


}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 35%;
}

div.card {
  padding: 15px;
  text-align: center;
}

div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.php" >

          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Fornos</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 

        <div class="container" >
          <div class="row">

         
  <div class="card">
    <img class="card-img-top" src="for1.jpg"  ">
    <div class="card-body">
      <h5 class="card-title" >Forno BOSCH HBA534ES0  </h5>
      <p class="card-text" >O forno Bosch HBA534ES0 com tecnologia de ar quente 3D atinge resultados perfeitos na confeção de assados e bolos em até três níveis em simultâneo. A tecnologia de ar quente 3D assegura assim resultados perfeitos graças à distribuição ótima do calor, ao passo que o raile telescópico de um nível permite a inserção e a remoção segura e fácil dos tabuleiros. Também em destaque no forno Bosch HBA534ES0, o sistema EcoClean Direct de limpeza sem esforço, graças à superfície especial da parede traseira, que absorve automaticamente as gorduras, e o visor LED para operação e controlo intuitivos. Ainda em evidência, os sete modos de aquecimento (ar quente 3D, Calor superior/inferior, grelha de infravermelhos em circulação, grelha grande, base para pizza, aquecimento inferior e ar quente suave) e o temporizador eletrónico para tempo de confeção e alarme. Outras características: controlo de temperatura eletrónico de 50 ºC a 275 ºC; volume interno de 71 litros; ventilador de refrigeração; iluminação interna de halogéneo; sistema deslizante; extensão telescópica simples, com função de paragem; pega de aço inoxidável; interior da porta em vidro; aquecimento rápido; segurança infantil.</p>

    
    </div>
    <a href="li1.php" class="btn btn-primary">Ver Mais</a>
  </div>


  <div class="card" >
    <img class="card-img-top" src="for2.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Forno HOTPOINT FA2 841 JH IX HA </h5>
      <p class="card-text">O forno de encastre Hotpoint-Ariston FA2 841 JH IX HA em aço inoxidável, com capacidade líquida de 71 litros e potência máxima de 2900 W, insere-se na classe de eficiência energética A+. O painel de controlo contém ecrã digital com botões de toque suave e dois botões rotativos escamoteáveis para permitir selecionar entre os oito modos de aquecimento e regular a temperatura de confeção, bem como programar o tempo de cozedura de forma precisa, conferindo assim ao utilizador total controlo sobre os alimentos. No interior, o forno de encastre Hotpoint-Ariston FA2 841 JH IX HA contém guias telescópicas para facilitar a utilização da grelha, do tabuleiro universal e do tabuleiro de recolha de molhos. Outras características relevantes: iluminação interior em halogéneo; porta em vidro duplo; sistema de limpeza hidrolítico; ventilação de aquecimento e arrefecimento; grill elétrico com potência de 1800 W.</p>
      
      
    </div>
     <a href="li2.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="for3.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Forno BECKEN BBIO5046 </h5>
      <p class="card-text">Todos os dias e a uma velocidade constante, a BECKEN tem vindo a melhorar a funcionalidade dos seus equipamentos domésticos. O forno de encastre BECKEN BBIO5046, com uma magnifica capacidade líquida de 80 litros e potência máxima de 2400 W, insere-se na classe de eficiência energética A. O painel de controlo contém ecrã digital com botões de toque suave e dois botões rotativos escamoteáveis para permitir selecionar entre os sete modos de aquecimento e regular a temperatura de confeção, bem como programar o tempo de cozedura de forma precisa, conferindo assim ao utilizador total controlo sobre os alimentos.</p>
      
        
    </div>
     <a href="li3.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >


      <div class="row">
   <div class="card">
    <img class="card-img-top" src="for4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Forno KUNFT KBIO3954  </h5>
O forno Kunft KBIO3954 é um prático e simples equipamento de cozinha de tipo estático com capacidade interior de 64 litros que soma quatro programas de cocção, dando-lhe flexibilidade suficiente para preparar as mais deliciosas iguarias. Com aquecimento inferior e superior, este forno Kunft KBIO3954 destaca-se também pelo vidro duplo na porta do forno e pelo facto de inserir-se na classe de eficiência energética A, assegurando baixo consumo de eletricidade. Outras características relevantes: controlos rotativos analógicos; potência de 1200 W (superior) e 1100 W (inferior); grill elétrico com potência máxima de 1400 W; temperatura máxima de 50º C a 270º C. Dimensões (AxLxP): 59,5 x 59,5 x 57,5 cm. Peso de 35 kg.      
      
    </div>
     <a href="li4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="for5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Forno TEKA HBB 635 IX </h5>
      <p class="card-text">O forno pirolítico Teka HBB 635 IX com tecnologia de autolimpeza Hidroclean transforma sujidade, gordura e resíduos de alimentos através do poder das altas temperaturas e água para o ajudar a limpar com a força do vapor. Por sua vez, o sistema de ventilação garante que o ar quente circula uniformemente por toda a cavidade do forno, ao passo que a resistência circular adicional assegura que os seus pratos são cozinhados uniformemente – mesmo quando colocamos tabuleiros em dois ou três níveis em simultâneo na cavidade do forno. Já o temporizador do visor proporciona ainda mais controlo sobre os seus cozinhados. Outras características: inox com tratamento antidedadas; regulação eletrónica da temperatura; bloqueio de segurança; segurança para crianças; funções eletrónicas; iluminação interior de halogéneo; porta de fácil limpeza; ventilador de arrefecimento; classe de eficiência energética A+; 2615 W de potência.</p>
      
      
    </div>
     <a href="li5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="for6.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Forno a Vapor AEG SteamBake BPE555320M </h5>
      <p class="card-text">O forno AEG SteamBake BPE555320M, com volume de 71 litros e potência máxima de 3500 W, conta com a função PlusSteam e soma dois ciclos de pirólise e 10 funções de aquecimento. Graças à porta Touch Top, o exterior da porta do forno permanece relativamente frio ao toque, para uma interação segura em todas as circunstâncias. Acrescendo a todas as funções standard do forno, a função PlusSteam adiciona vapor no início do processo de cozedura. A cozedura a vapor mantém a massa húmida na superfície, o que contribui para que a crosta fique dourada, estaladiça e saborosa, enquanto o interior fica suave e macio. Além de assar pães estaladiços e deliciosos, muffins, bolos e tortas, também o seu frango assado, carnes e lasanhas vão ficar igualmente saborosos. Com o toque da função de limpeza por pirólise, sujidade, gordura e resíduos de alimentos no forno são transformados em cinzas que pode facilmente limpar com um pano húmido. Com este forno AEG SteamBake BPE555320M, a utilização eficiente da energia também significa cozinhar eficientemente. O novo sistema de ventilação Hot Air garante que o ar quente circula de modo uniforme por toda a cavidade. Como resultado, o forno aquece mais rapidamente e as temperaturas de cozedura podem ser reduzidas até 20%, poupando tempo e energia. Por sua vez, o temporizador do avançado painel Hexagon dá-lhe ainda mais controlo sobre os seus cozinhados. Ao definir o início e o fim no visor LCD, o forno inicia e termina a cozedura no momento indicado, o que significa que pode ter a garantia de precisão absoluta, mesmo se estiver longe do seu forno momentaneamente. Por fim, a tecnologia Soft Closing Door incorporada na porta de fecho suave garante que esta fecha sempre suave e silenciosamente.</p>
      
        
    </div>
     <a href="li6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >
       <div class="row">
  <div class="card" >
    <img class="card-img-top" src="for7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Forno a Vapor CANDY FCP 651 SX</h5>
      <p class="card-text">
     
O forno a vapor Candy FCP 651 SX, com capacidade interior de 70 litros, tem tudo aquilo de que precisa para facilitar a confeção de refeições. Uma vez que se trata de um forno multifuncional, permite-lhe cozinhar de várias formas diferentes, quer esteja a assar com a configuração do ventilador ou a preparar um lanche de queijo com torradas na grelha. A opção de grelhar ventilada usa ambos os recursos, combinando o poderoso calor de cima com o ar quente circulado para carne suculenta. Além disso, o forno a vapor Candy FCP 651 SX conta também com uma excelente função de cozimento a vapor que adiciona humidade extra para selar o sabor no interior. Com a utilização de água para manter tudo impecável, o forno a vapor Candy FCP 651 SX destaca-se ainda pela função de limpeza Aquactiva, que solta os resíduos de alimentos e facilita a limpeza.
</p>
      
      
    </div>

     <a href="li7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="for8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Forno CANDY CELF 602 X  </h5>
      <p class="card-text">O forno multifunções Candy CELF 602 X em inox, com volume de 65 litros, soma oito funções, das quais: lâmpada, descongelação, Fan Assisted (Inferior + Superior + Ventilador), Grill + Ventilador, Inferior + Ventilador, Estático (Inferior + Superior), Grill e Pizza. Também em destaque no forno multifunções Candy CELF 602 X, o temporizador de até 60 minutos, a porta interna de vidro duplo e as pegas em aço inoxidável.</p>
      
      
    </div>
     <a href="li8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="for9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Forno BOSH HOME CONNECT HSG636XS6</h5>
      <p class="card-text">O forno de vapor Bosch Home Connect HSG636XS6 com sensor PerfectBake e sonda térmica PerfectRoast com três sensores de medição de temperatura assegura resultados perfeitos e de forma automática. Este forno Home Connect, que conta com conetividade inteligente via Internet para facilitar as tarefas diárias, destaca-se também pelo assistente de cozinha, que faz ajustes automáticos do modo de aquecimento para que possa preparar inúmeros pratos. Também em evidência neste forno Bosch Home Connect HSG636XS6, os controlos com visor TFT tátil muito fácil de usar graças ao seu aro de controlo central e a todas as funcionalidades com textos e imagens a cores.  </p>

    </div>
     <a href="li9.php" class="btn btn-primary">Ver
      Mais</a>
  </div>

</div>

                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos liui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>