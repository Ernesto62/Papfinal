<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;


}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 35%;
}

div.card {
  padding: 15px;
  text-align: center;
}

div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}

  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.php" >

          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Promoções</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 

         <div class="container">
             <div class="row">

         
  <div class="card" >
    <img class="card-img-top" src="sec3.jpg" alt="Card image cap">
    <h1 style='color:#007aff;'><b>|-25%|</b></h1>
    <div class="card-body">
      <h5 class="card-title">Secador de Cabelo ROWENTA Cv8732f0 </h5>
      <p class="card-text">O secador de cabelo Rowenta Infini Pro garante uma secagem de cabelo profissional. Impulsionado por um motor AC potente com um elevado fluxo de ar para uma secagem mais rápida, este secador confere precisão com o seu concentrador de ar ultra-fino de apenas 6 mm. Um total de 6 diferentes posições (velocidade e temperatura) asseguram resultados adaptados ao seu tipo de cabelo. Com um sistema iónico para eliminar a eletricidade estática, o Infini Pro confere um tratamento completo digno de um salão de beleza profissional.
      
        
    </div>
     <a href="sec3.php" class="btn btn-primary">Ver Mais</a>
  </div>



  <div class="card" >
    <img class="card-img-top" src="eira6.jpg" alt="Card image cap">
      <h1 style='color:#007aff;'><b>|-25%|</b></h1>
    <div class="card-body">
      <h5 class="card-title">Cafeteira Elétrica BECKEN IX BWK1053 </h5>
      <p class="card-text">O cafeteira elétrica Becken LX BWK1053 em inox foi desenvolvido a pensar em si. Com capacidade de 1,7 litro e potência de 1850 a 2200 W, o cafeteira elétrica Becken LX BWK1053 consegue aquecer mais água em menos tempo. O indicador do nível de água, a tampa com fecho e o filtro anti-calcário possibilitam uma utilização mais fácil e adequada para que possa poupar tempo, libertando-o para outras atividades. De design elegante e moderno, este cafeteira elétrica Becken LX BWK1053 é facilmente transportável sempre que precisar. Poderá ainda tirar todas as dúvidas no manual de instruções incluído na embalagem. Dimensões (AxLxP): 21,5 x 16,1 x 22,5 cm. Peso de 1,025 kg. Outras características relevantes: desligamento automático; sistema de segurança; filtro anti-impurezas. Garantia de dois anos.A Worten destaca: cafeteira elétrica com capacidade de 1,7 litro; potência de 1850 a 2200 W; indicador do nível; filtro anti-calcário; desligamento automático; luz piloto.</p>
      
        
    </div>
     <a href="eira6.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="fe2.jpg" alt="Card image cap">
    <h1 style='color:#007aff;'><b>|-25%|</b></h1>
    <div class="card-body">
      <h5 class="card-title">Ferro de Engomar Philips GC4567/80 </h5>
      <p class="card-text">Ferro a Vapor GC4567/80 da Philips com potência máxima de 2600 W,para um aqueciemnto rápido e um desempenho potente. Destaca-se pela base SteamGlide Advanced que proporciona um deslizar ultra rápido ao seu engomar e resistente a riscos. Antiaderente, resistente a riscos e fácil de manter limpo.A função de vapor constante expele 50 gramas de vapor por minuto, amaciando a roupa para facilitar a engomagem. Se os tecidos oferecerem demasiada resistência, utilize a função de jato de vapor(220 g/min.)para amolecer a roupa de forma mais eficaz.
Com design inovador este ferro a vapor da Philips consegue facilmente remover as partículas de calcário, e automaticamente são recolhidas no recipiente para calcário amovível.
Outras características importantes são a sua temperatura regulável, o modo de poupança de energia, o sistema anticalcário e antigota.</p>
      
      
    </div>
     <a href="li2.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container">
             <div class="row">
  <div class="card" >
    <img class="card-img-top" src="sec4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Secador de Cabelo ROWENTA Cv5384F0 </h5>
      <p class="card-text">Com o secador Studio Dry da Rowenta desfrute de uma secagem eficiente do cabelo. Este secador é muito fácil de usar, tem uma potência de 2100 Effiwatts para um excelente desempenho, enquanto poupa até 20% de energia. O concentrador Triple Air Precision fornece um fluxo de ar preciso para um estilizar perfeito, possui 3 posições de temperatura/velocidade para adaptar às suas necessidades de secagem. Este secador de alta eficiência tem sistema ionico para reduzir a eletrecidade estática do cabelo e fluxo de ar frio para finalizar a sessão e garantir resultados duradouros.</p>
      
      
    </div>
     <a href="sec4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="sec5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Secador ROWENTA CV5940F0 Premium Care Powerline </h5>
      <p class="card-text">Para uma aparência deslumbrante com um brilho requintado, o secador Rowenta Powerline oferece uma secagem impecável. A tecnologia Ionic Booster reduz a eletricidade estática, deixando os cabelos macios e cheios de brilho. Motor CC equipado com a tecnologia Effiwatts que garante um excelente desempenho e eficiência e ainda economiza energia dia após dia. Características de excelência: seis configurações de velocidade / temperatura para total adaptação consoante as suas necessidades, total controlo na ponta dos dedos, a tecnologia Advanced Care evita superaquecimento, para total proteção do cabelo ao calor mantendo-o saudável, opção de fluxo de ar frio para um toque final perfeito e resultados duradouros. Rowenta Powerline: gama completa de secadores de cabelo para um brilho radiante.</p>
      
      
    </div>
     <a href="sec5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="sec6.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Secador de Cabelo REMINGTON Pro D5715</h5>
      <p class="card-text">O secador Thermacare Pro 2300 alia a secagem rápida a uma maior proteção* Secador de 2100 W potente, porém gentil, que oferece a mesma velocidade de secagem como um secador de 2300 W, mas com menos calor para mais proteção. Com o seu design compacto e leve, o secador Thermacare Pro 2300 é perfeito para quando está em viagem. Não só tem um visual perfeito, como também tem um som perfeito! A secagem mais silenciosa deste secador de ruído reduzido proporciona-lhe uma experiência de modelação superior.A grelha de cerâmica proporciona uma distribuição de calor uniforme e constante, ao passo que o condicionamento iónico, com 90% mais iões, resulta num brilho sem frisagem.</p>
      
        
    </div>
     <a href="sec6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
         <div class="container">
             <div class="row">
  <div class="card" >
    <img class="card-img-top" src="sec7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Secador de Cabelo ROWENTA CV9820F0 Ultimate Experience </h5>
      <p class="card-text">
     
Tecnologia Air-to-Care com ação dupla de iões positivos que ajudam a restaurar o equilíbrio natural do cabelo, protegendo-o do pó e poluição, e negativos que reduzem a eletricidade estática e frisado para resultados brilhantes e suaves.Passe de secar a estilizar apenas num clique com o sistema Switch & Style. O Concentrador integrado é acionado estreitando a saída do fluxo de ar para resultados mais precisos.3 níveis de temperatura e 3 níveis de velocidade que se adaptam a cada tipo de cabelo. A Tecnologia Smart Memory regista a última combinação de temperatura e velocidade utilizada para que na próxima secagem não tenha de reprogramar.A função de ar frio permanente, oferece um fluxo constante para finalizar o penteado e obter resultados de longa duração.Motor digital BLDC extremamente durável para uma secagem rápida e eficiente num formato leve e compacto.

</p>
      
      
    </div>
     <a href="sec7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="sec8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Secador de Cabelo REMINGTON AIR3D D7777  </h5>
      <p class="card-text">O secador de cabelo Remington Air3D D7777, concebido para obter a melhor modelação sem que se preocupe em danificar o cabelo, possui três posições de calor e alcança uma temperatura elevada o suficiente para ajudar a modelar o seu cabelo com facilidade. Use as temperaturas mais elevadas para secar e modelar, e as mais baixas para fixar, de forma a obter um penteado duradouro. Além disso, com o secador de cabelo Remington Air3D D7777 passe menos tempo à frente do espelho e mais tempo fora de casa a exibir o seu penteado brilhante e sem frisagem. O fluxo de ar 3D único cria uma rajada de ar potente ininterrupta para penteados de longa duração. Outras características: condicionamento iónico para um cabelo brilhante e sem frisagem; corpo equilibrado e leve; três temperaturas e duas velocidades; jato de ar fresco para fixar o penteado; motor DC de 1800 W de potência; sistema de bloqueio dos acessórios por pressão; dois concentradores + difusor; gancho para pendurar; pega antiderrapante; caixa de armazenamento.</p>
      
      
    </div>
     <a href="sec8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="sec9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Secador de Cabelo DYSON Supersonic 305967</h5>
      <p class="card-text">O secador de cabelo Dyson Supersonic conta com um potente motor digital que assegura o controlo inteligente do calor para um brilho natural. Além disso, ajuda a evitar os danos produzidos pelo calor extremo, uma vez que a temperatura é medida 20 vezes por segundo, o que ajuda a mantê-la controlada. Porque secar o cabelo não deveria demorar uma eternidade, o secador de cabelo Dyson Supersonic oferece uma secagem rápida, com fluxo de ar controlado, a alta velocidade. Acresce que a Dyson revolucionou o funcionamento convencional e colocou o motor no manípulo, reequilibrando totalmente o peso e a forma do secador. Por sua vez, o bico concentrador Dyson seca e penteia ao mesmo tempo, usando um fluxo de ar suave e amplo.  Controlado por apenas quatro botões, o secador Dyson Supersonic soma ainda três definições de velocidade de precisão (secagem rápida, secagem normal e modelação) e quatro definições de temperatura de precisão (100° C para secagem e modelagem rápidas, 80° C para secagem normal, 60° C para secagem suave e 28° C para frio constante). Outras características: fácil de limpar; cabo de alimentação profissional com 2,7 metros; acessórios magnéticos; tecnologia Heat Shield (escudo térmico) para superfície fria; potência de 1600 W; bico concentrador fino. </p>
      
        
    </div>
     <a href="sec9.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>


                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos secui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>