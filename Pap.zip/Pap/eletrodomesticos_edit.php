<?php

session_start();
if (!isset($_SESSION['login'])) {
	$_SESSION['login']="incorreto";
}
if($_SESSION['login']=="correto"&& isset($_SESSION['login'])){	







if ($_SERVER['REQUEST_METHOD']=="GET") {
	if (isset($_GET['eletrodomestico'])&& is_numeric($_GET['eletrodomestico'])) {
		$ideletrodomestico=$_GET['eletrodomestico'];
		$con=new mysqli("localhost","root","","eletrodomesticos");

		if ($con->connect_errno!=0) {
				echo "Erro".$connect_error."</h1>";
				exit();

		}
		$sql="Select * from eletrodomesticos where id=?";
		$stm=$con->prepare($sql);
		if ($stm!=false) {
				$stm->bind_param('sssii',$elet,$imagem,$descricao,$categoria,$preco);
				$stm->execute();
				$res=$stm->get_result();
				$eletrodomestico=$res->fetch_assoc();
				$stm->close(); 
		}
	
				  ?>
	  <!DOCTYPE html>
	  <html>
	  <head>
	  	<title></title>
	  	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="fa/css/all.css">
	<script type="text/javascript" src="fa/js/all.js"></script>
	 <script src="js/jquery-3.5.1.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
	  </head>
	  <body>
	  <h1>Editar Eletrodomésticos</h1>

<?php 
$stm=$con->prepare('select * from eletrodomesticos');
$stm->execute();
$res=$stm->get_result();
while ( $resultado=$res->fetch_assoc() ) {

}
 ?>

	  <form action="eletrodomesticos_update.php?eletrodomestico=<?php  echo $eletrodomestico['id']; ?>" method="post">

	<label>Eletrodomestico</label><input type="text" name="eletrodomestico" value="<?php echo $eletrodomestico['eletrodomestico'];?>"><br><br>
	<label>Imagem</label><input type="file" name="imagem" value="<?php echo $imagem['imagem'];?>"><br><br>

	<label>Descrição</label><input type="text" name="descricao" value="<?php echo $descricao['descricao'];?>"><br><br>
	<label>Categoria</label><input type="text" name="categoria" value="<?php echo $categoria['categoria'];?>"><br><br>
	<label>Preço</label><input type="text" name="preco" value="<?php echo $preco['preco'];?>"><br><br>
	
	<input type="submit" name="enviar">
</form>

	  </body>
	  </html>
	  <?php
	}	
else{
	echo ("Erro");
	header("refresh:5; url=index.php");
	}
		$stm->close();
}	



}
else{
	echo " <a href='login.php'>login</a>";
	header('refresh:2;url=login.php');
}

?>