<?php 


    



if ($_SERVER['REQUEST_METHOD']=="POST") {
    
    $nome="";
    $email="";
    $palavra_passe="";
    

    if (isset($_POST['nome'])) {
        $nome=$_POST['nome'];
    }
      if (isset($_POST['email'])) {
        $email=$_POST['email'];
    }
      if (isset($_POST['palavra_passe'])) {
        $palavra_passe=$_POST['palavra_passe'];
    }
    else{
        
    }
    
    $con=new mysqli("localhost","root","","eletrodomesticos");
    if ($con->connect_errno!=0) {
        echo "ERRO.<br>".$con->connect_erro;
        exit;
    }
    else{
        $sql='insert into utilizadores (nome,email,palavra_passe) values (?,?,?)';

        $stm=$con->prepare($sql);
        if ($stm!=false) {
            $stm->bind_param('sss',$nome,$email,$palavra_passe);
            $stm->execute();
            $stm->close();

            echo "<script>alert('Adicionado com sucesso')</script>";

            

            header("refresh:5; url=index.html");
        }
        else{
            echo ($con->error);
            
            header("refresh:5; url=index.html");
        } 
    } 
} 