<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;


}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 35%;
}

div.card {
  padding: 15px;
  text-align: center;
}

div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.php" >

          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Frigoríficos</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 

        <div class="container" >
          <div class="row">

         
  <div class="card">
    <img class="card-img-top" src="fri1.jpg"  ">
    <div class="card-body">
      <h5 class="card-title" >Frigorífico Combinado Hotpoint-Ariston H8-A1E-W 338L  </h5>
      <p class="card-text" >O H8-A1E-W, conta com 338L de capacidade útil e insere-se na classe de eficiência energética F, o que permite uma maior poupança nas despesas de energia. Dispõe de uma autonomia de 24h em caso de falha de energia e tem um nível de emissão de ruído de apenas 38dB. Conta ainda com o inovador sistema de iluminação LED garante uma luminosidade intensa, com uma luz mais suave para os seus olhos.</p>

    
    </div>
    <a href="fri1.php" class="btn btn-primary">Ver Mais</a>
  </div>


  <div class="card" >
    <img class="card-img-top" src="fri2.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Frigorífico 2 Portas Jocel JF-206L E 206L </h5>
      <p class="card-text">O JF-250L da Jocel, com capacidade do frigorifico de 169 litros e do congelador 37 litros, insere-se na classe de eficiência energética F O seu interior conta com um total de 6 prateleiras em vidro, 4 no frigorífico e 2 no congelador, o que lhe confere diversas soluções de arrumação.Frigorifico com sistema de resfriamento estático que oferece resfriamento rápido e limpo com baixo consumo. Possui distribuição homogênea e instantânea do frio em todo o compartimento refrigerador. Ele mantém uma temperatura constante e proporciona uma ótima preservação dos alimentos.O seu consumo de energia é de 172 kWh/ano, a emissão de ruído 40dB e a classe climática é ST.</p>
      
      
    </div>
     <a href="fri2.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="fri3.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Frigorífico Combinado Jocel JC-273LID 267L - Inox com Dispensador Água </h5>
      <p class="card-text">Este combinado de instalação livre da Jocel com dispensador de água apresenta uma capacidade de 68 litros no congelador e de 199 litros no frigorífico e insere-se na classe de eficiência energética F (Nova). Destaque para o seu consumo de energia de 237 kWh/ano e nível de ruído de apenas 42dB.</p>
      
        
    </div>
     <a href="fri3.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >


      <div class="row">
   <div class="card">
    <img class="card-img-top" src="fri4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Frigorífico Combinado Hotpoint XH8 T3U X 338L No Frost  </h5>
      <p class="card-text">O frigorífico combinado Hotpoint XH8 T3U X de eficiência energética A+++ e 37 dB de emissão de ruído. A Zona de Temperatura Variável, cujo o compartimento congelador pode ser regulado para qualquer temperatura entre 0° C e - 26° C a fim de criar as condições de conservação ideais para o tipo de alimento.
      Tem capacidade total de 338L( frigorífico 234L + congelador 104L ). Tem uma autonomia de 17h em caso de falha de energia e uma capacidade de congelação de 10Kg por dia. Para além de tudo isto, dispõe ainda de um sistema de refrigeração Total No Frost. Garantia de dois anos.</p>
      
      
    </div>
     <a href="fri4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="fri5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Frigorífico Combinado Indesit XIT8 T2E W 320L NoFrost </h5>
      <p class="card-text">Frigorífico combinado XIT8 T2E W com capacidade de 320 litros, classe de eficiência energética E (Nova). Capacidade de congelação de 4 Kg em 24 horas. Classe climática N-T e Iluminação LED. Nível de ruído 42 dB. Modelo alto e espaçoso, adequado para as necessidades de toda a família. Cor branca. No Frost, a tecnologia que impede efetivamente a formação de gelo no congelador, reduzindo os níveis de humidade. Prateleiras de vidro, robustas e elegantes ao mesmo tempo. Fluxo de ar regular e uniforme dentro do aparelho, para ventilação aprimorada.</p>
      
      
    </div>
     <a href="fri5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="fri6.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Frigorífico Combinado Bosch KGV36VIEAS 307L LowFrost - Inox </h5>
      <p class="card-text">Combinado Bosch KGV36VIEAS de eficiência energética  E (Nova) e 39dB de emissão de ruído tem 308L de capacidade útil. Tem uma autonomia de 23h em caso de falha de energia e uma capacidade de congelação de 7Kg por dia. Para além de tudo isto, dispõe da tecnologia LowFrost, Gaveta BigBox e iluminação interior LED .</p>
      
        
    </div>
     <a href="fri6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >
       <div class="row">
  <div class="card" >
    <img class="card-img-top" src="fri7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Frigorífico Americano Jocel JSBS014207 A+ 514L NoFrost - Inox</h5>
      <p class="card-text">
     
Frigorífico americano JSBS014207 da Jocel tem uma capacidade total de 514L, dos quais 342L para o frigorífico e 172L no congelador. Utiliza dois fluxos de ar independentes e um controlo de temperatura de grande precisão para garantir os níveis de humidade ideais em todas as zonas do frigorífico. Este frigorífico americano insere-se na classificação energética A+ e o seu consumo energético 1100 kWh/24h .Tudo isto com uma emissão de ruído de apenas 43 dB, dispõe de dispensador de água com capacidade de 3L.

</p>
      
      
    </div>

     <a href="fri7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="fri8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Frigorífico Americano LG GSJ761PZZZ Door-In-Door 601L NoFrost Inox  </h5>
      <p class="card-text">O GSJ761PZZZ Door-In-Door, frigorífico americano da LG, tem uma capacidade total de 601L, insere-se na classificação energética F (Nova) e apresenta um sistema de frio No Frost total. O seu consumo energético anual é de 376kWh, a sua capacidade de congelamento diário de 12 Kg e a sua emissão de ruído de apenas 39 dB. Para além de tudo isto, este frigorífico americano possui dispensador de gelo e água e 4 prateleiras. Dispensador de água e gelo sem canalização.</p>
      
      
    </div>
     <a href="fri8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="fri9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Frigorífico Americano LG GSX961NSVZ 601L No Frost Inox</h5>
      <p class="card-text">Frigorífico americano LG GSX961NSVZ em aço inoxidável. Capacidade líquida total de 601 litros: 196 litros (congelador) e 405 litros (frigorífico). Classe de eficiência energética A++ e sistema de gelo SpacePlus que garante mais espaço de congelação, oferencedo 20 vezes mais espaço de armazenamento de gelo em comparação com os frigoríficos convencionais. Carateriza-se também pelo seu sistema InstaView Door in Door que apresenta num painel de vidro espelhado e sofisticado que permite visualizar o que está no interior se teres que abrir a porta. O Frigorífico GSX961NSVZ dispõe de tecnologia Smart ThinQ, compressor Inverter linear, nível de ruído de 39 dB e capacidade de congelação de 12 Kg em 24 horas. Consumo anual de energia de 376 kWh. </p>

    </div>
     <a href="fri9.php" class="btn btn-primary">Ver
      Mais</a>
  </div>

</div>

                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos friui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>