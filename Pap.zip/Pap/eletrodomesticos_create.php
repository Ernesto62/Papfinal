<?php 

/*session_start();
if (!isset($_SESSION['login'])) {
	$_SESSION['login']="incorreto";
}
if($_SESSION['login']=="correto" && isset($_SESSION['login'])){
	
*/


if ($_SERVER['REQUEST_METHOD']=="POST") {
	
	
	$elet="";
	$imagem="";
	$novo_nome="";
	$descricao="";
	$categoria="";
	$preco="";

	

	if (isset($_POST['eletrodomestico'])) {
		$elet=$_POST['eletrodomestico'];
		
	}
	if (isset($_POST['descricao'])) {
		$descricao=$_POST['descricao'];

	}
	if (isset($_POST['categoria'])) {
		$categoria=$_POST['categoria'];
	}
	if (isset($_POST['preco'])) {
		$preco=$_POST['preco'];
	}
	  if(isset($_FILES['imagem'])){
            date_default_timezone_set('Europe/London'); //timezone local para adicional ao nome da imagem
            $ext=strtolower(substr($_FILES['imagem']['name'], -4)); //extensão da imagem
            $novo_nome=date("Y.m.d-H.i.s").$ext; //atribuir novo nome à imagem
            $dir='imagens/';
            move_uploaded_file($_FILES['imagem']['tmp_name'], $dir.$novo_nome); //upload do ficheiro
        }
        $imagem=$novo_nome;
	
	
	$con=new mysqli("localhost","root","","eletrodomesticos");
	if ($con->connect_errno!=0) {
		echo "ERRO.<br>".$con->connect_erro;
		exit;
	}
	else{
		$sql='insert into eletrodomesticos (eletrodomestico,imagem,descricao,categoria,preco) values (?,?,?,?,?)';
		$stm=$con->prepare($sql);
		if ($stm!=false) {
			$stm->bind_param('ssssi',$elet,$imagem,$descricao,$categoria,$preco);
			$stm->execute();
			$stm->close();

			echo "<script>alert('Adicionado com sucesso')</script>";

			

			header("refresh:5; url=index.php");
		}
		else{
			echo ($con->error);
			
			header("refresh:5; url=index.php");
		} 
	} 
} 


else{

 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	
</head>
<body>
<h1>Adicionar Eletrodoméstico</h1>
<form action="eletrodomesticos_create.php" method="post" enctype="multipart/form-data" >

	<label>Eletrodoméstico</label><input type="text" name="eletrodomestico" required><br><br>
	<label>Imagem</label><input type="file" name="imagem" required><br><br>
	<label>Descricao</label><input type="text" name="descricao" required><br><br>
	<label>Categoria</label><input type="text" name="categoria" required><br><br>
	<label>Preço</label><input type="numeric" name="preco" required><br><br>
	
	<input type="submit" name="enviar">
</form>
</body>
</html>
<?php  
}


//}


?>