<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;


}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 30%;
}

div.card {
  padding: 15px;
  text-align: center;
}

div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.php" >

          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Batedeiras</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 

        <div class="container" >
          <div class="row">

         
  <div class="card">
    <img class="card-img-top" src="bat1.jpg"  ">
    <div class="card-body">
      <h5 class="card-title" >Batedeira BOSCH MFQ4030  </h5>
      <p class="card-text" >A batedeira Bosch MFQ4030 é especialmente silenciosa, leve e potente, para maior conforto durante a utilização. Além do design moderno, destaque para a inclusão de duas varas FineCreamer em aço inoxidável para bater e misturar, assegurando os mais rápidos e perfeitos resultados. Também em evidência, o motor de 500 W a cinco velocidades e o botão turbo. Outras características: duas varas para bater e misturar e duas varas para amassar; botão independente para expulsão das varas; possibilidade de encaixar um pé de varinha; pé de fácil extração com botão de ejeção; enrolador de cabo.</p>

    
    </div>
    <a href="bat1.php" class="btn btn-primary">Ver Mais</a>
  </div>


  <div class="card" >
    <img class="card-img-top" src="bat2.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Batedeira BECKEN BHM3133 </h5>
      <p class="card-text">A batedeira Becken BHM3133, com potência máxima de 400 W, inclui duas varetas e apresenta um botão rotativo de regulação de velocidade que permite escolher entre cinco velocidades. O botão Turbo possibilita a utilização da batedeira na potência máxima quando é necessário bater com maior intensidade. A batedeira Becken BHM3133 inclui também um botão de ejeção das varetas para facilitar a desmontagem. Outras características relevantes: varetas laváveis na máquina de lavar loiça; pás misturadoras e pás batedoras incluídas; leveza (peso inferior a 1 kg). Garantia de dois anos.A Worten destaca: batedeira com potência máxima de 400 W, cinco velocidades e botão rotativo de seleção de velocidades; botão de ejeção de varetas; botão Turbo; leveza; varetas laváveis na máquina de lavar loiça; pás misturadoras e pás batedoras.</p>
      
      
    </div>
     <a href="bat2.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="bat3.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Batedeira BOSCH MFQ3010 </h5>
      <p class="card-text">A batedeira sem taça Bosch MFQ3010, com potente, leve e silencioso motor de 300 W, é de utilização fácil e está equipada com duas varas para bater e misturar e duas varas para amassar. O aparelho inclui diversos acessórios de fácil limpeza, aptos para lavagem na máquina de lavar loiça. Destaque para as suas duas velocidades, para o botão turbo e para a sua grande ergonomia e resistência ao impacto. Também em evidência, a pega adaptada para esquerdinos e destros, o botão independente para expulsão das varas e o enrolador de cabo.</p>
      
        
    </div>
     <a href="bat3.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >


      <div class="row">
   <div class="card">
    <img class="card-img-top" src="bat4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Batedeira BOSCH MFQ36460   </h5>
      <p class="card-text">A potente batedeira com suporte e taça rotativa Bosch MFQ36460 permite uma operação mãos-livres e destaca-se desde logo pelo motor silencioso de 450 W e cinco velocidades para máximo desempenho e melhores resultados. Também em destaque, a inclusão de um suporte e uma taça de 2,8 litros para confortável operação mãos-livres. Ainda em evidência, o design ergonómico com cobertura soft-touch anti-derrapante e pega confortável, bem como os acessórios de fácil limpeza, aptos para lavagem na máquina de lavar loiça. Outras características: botão turbo; botão independente para expulsão das varas; duas varas turbo para bater e misturar; duas varas em aço inoxidável para amassar.</p>
      
      
    </div>
     <a href="bat4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="bat5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Batedeira BECKEN BHMB3134 </h5>
      <p class="card-text">A batedeira Becken BHMB3134, com taça incorporada com capacidade de 3.2L e potência máxima de 400 W, inclui duas varetas e apresenta um botão rotativo de regulação de velocidade que permite escolher entre cinco velocidades. O botão Turbo possibilita a utilização da batedeira na potência máxima quando é necessário bater com maior intensidade. Por sua vez, a taça em plástico gira durante a utilização da batedeira para assegurar melhores resultados e para garantir que todo o conteúdo da taça é misturado. Por fim, a batedeira Becken BHMB3134 inclui também um botão de ejeção das varetas para facilitar a desmontagem. Outras características relevantes: varetas laváveis na máquina de lavar loiça; pás batedoras e pás misturadoras incluídas. Garantia de dois anos.A Worten destaca: batedeira com potência máxima de 400 W, taça incorporada e taça rotativa em plástico; cinco velocidades de funcionamento; botão rotativo de seleção de velocidades; botão de ejeção de varetas; botão Turbo; pás batedoras e pás misturadoras; varetas laváveis na máquina de lavar loiça.</p>
      
      
    </div>
     <a href="bat5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="bat6.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Batedeira CLATRONIC KM 3630 </h5>
      <p class="card-text">A batedeira Clatronic KM 3630, com elevada potência de 1200 W, proporciona alto desempenho com base em oito configurações de velocidade (0/1/2/3/4/5/6 + Pulse). Também em destaque nesta batedeira Clatronic KM 3630, a taça de aço inoxidável com capacidade de 6,3 litros para preparação de misturas de 3 a 3,5 kg, o batedor de alumínio fundido, que também permite a mistura uniforme de quantidades consideráveis de massa, e o gancho de massa de alumínio fundido para massas pesadas e levedura ou massa de pão. Ainda em evidência na batedeira Clatronic KM 3630, o batedor de aço inoxidável para bolos e claras em castelo, o robusto mecanismo de engrenagem e o braço multifunções giratório a 35°, não esquecendo o mecanismo de desbloqueio para braço multifuncional. Outras características relevantes: circuito de segurança; fácil operação e limpeza; suporte antiderrapante com pés de ventosa.</p>
      
        
    </div>
     <a href="bat6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >
       <div class="row">
  <div class="card" >
    <img class="card-img-top" src="bat7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Batedeira com Taça KENWOOD kMix KMX750WH </h5>
      <p class="card-text">
     
A batedeira Kenwood kMix KMX750WH de cor branca mistura, bate, amassa e envolve com facilidade todo o tipo de alimentos, sendo um excelente aliado na cozinha. Além de apresentar design elegante e moderno, este robot de cozinha Kenwood kMix KMX750WH é ótimo na preparação de alimentos, ideal para experimentar novas receitas e preparar manjares deliciosos para a família e amigos. A taça em aço inoxidável apresenta capacidade de 5 litros e pode ser lavável na máquina de lavar loiça. Um pequeno botão rotativo possibilita a seleção das seis velocidades de funcionamento disponíveis, com aumento gradual na mudança de velocidades. Outras características relevantes: batedor de pinha, batedor K e gancho de amassar incluídos; potência de 1000 W; corpo em metal; resguardo anti-salpicos com tubo de inserção de alimentos; ação planetária de mistura; encaixe para acessórios de baixa velocidade; armazenamento do cabo de alimentação elétrica. Garantia de dois anos.A Worten destaca: robot de cozinha com potência de 1000 W e taça em aço inoxidável com capacidade de 5 litros; funções de misturar, bater, amassar e envolver; batedor de pinha, batedor K e gancho de amassar incluídos; encaixe para acessórios de baixa velocidade; corpo em metal; resguardo anti-salpicos com tubo de inserção de alimentos; ação planetária de mistura.

</p>
      
      
    </div>

     <a href="bat7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="bat8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Batedeira com Taça SMEG Anni 50 SMF02SVEU  </h5>
      <p class="card-text">O movimento de rotação Planetário Optimum é gerado pela rotação simultânea do acessório e do Robot de Cozinha em si (em direções opostas), permitindo assim alcançar todos os pontos da taça de modo mais preciso. Porque o que precisa é de um assistente eficiente, para além dos acessórios incluídos, a Smeg oferece muitas outras soluções, a serem inseridas na parte da frental do robot.Na alavanca poderá ver a sugestão das 10 velocidades mais adequada a cada acessório, facilmente manobrável, para facilitar o trabalho. Adicionalmente, o robot de cozinha traz a função Arranque Suave, para prevenir o transbordo de ingredientes quando a mistura é iniciada.</p>
      
      
    </div>
     <a href="bat8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="bat9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Batedeira FLAMA Mixo 1405FL</h5>
      <p class="card-text">A batedeira Flama 1405 FL, com potência de 300 W e cinco velocidades, destaca-se pela função turbo e pela inclusão das varas batedoras e amassadoras metálicas. </p>

    </div>
     <a href="bat9.php" class="btn btn-primary">Ver
      Mais</a>
  </div>
</div>


                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos batui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>