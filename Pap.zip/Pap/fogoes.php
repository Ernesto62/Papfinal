<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;


}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 35%;
}

div.card {
  padding: 15px;
  text-align: center;
}

div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.php" >

          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Fogões</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 

        <div class="container" >
          <div class="row">

         
  <div class="card">
    <img class="card-img-top" src="fog1.jpg"  ">
    <div class="card-body">
      <h5 class="card-title" >Fogão de Gás BOSCH PPH6A6B20   </h5>
      <p class="card-text" > O Fogão a gás Bosch PPH6A6B20 com vidro temperado e tecnologia FlameSelect proporciona resultados perfeitos graças aos nove precisos níveis de potência. Em destaque nesta Fogão a gás Bosch PPH6A6B20, que apresenta quatro queimadores, o queimador Wok para cozinhar com elevada potência (até 3,3 kW), a possibilidade de opção integrada ou sob a bancada e as grelhas de ferro fundido com base de borracha, que asseguram estabilidade, comodidade e limpeza perfeita, não esquecendo a já referida função FlameSelect, cujos nove níveis de potência permitem ajustar o calor necessário com toda a facilidade e segurança. Ainda em evidência nesta Fogão a gás Bosch PPH6A6B20, os comandos ergonómicos, o isqueiro elétrico integrado no comando e a segurança termoelétrica.</p>

    
    </div>
    <a href="eletro_show.php?eletrodomesticos=2" class="btn btn-primary">Ver Mais</a>
  </div>


  <div class="card" >
    <img class="card-img-top" src="fog2.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Fogão de Gás AEG HKB64029NB841 JH IX HA </h5>
      <p class="card-text">Defina níveis precisos de intensidade de calor na Fogão com o sistema StepPower. Os controlos da Fogão podem ser definidos entre 1 e 9. O que significa que não é necessário baixar-se para ver a chama. Esta avançada tecnologia aquece de forma exata e consistente os seus tachos e panelas.O design único torna possivel uma completa integração dos queimadores nesta Fogão a gás, proporcionando uma superfície elegante e de fácil limpeza e a chama se apagar acidentalmente ou se o queimador for deixado ligado durante 4 horas sem intervenção, a alimentação de gás é desligada, garantindo a segurança perfeita.</p>
      
      
    </div>
     <a href="li2.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="fog3.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Fogão de Gás TEKA E 60.3 4G AI ALfogno BECKEN BBIO5046 </h5>
      <p class="card-text">A Fogão a gás butano/propano Teka E 60.3 4G AI AL BUT, com comandos laterais metalizados incorporados, soma quatro fiáveis queimadores - queimador auxiliar de 1 kW; dois queimadores semi-rápidos de 1,75 kW; queimador rápido de 3 kW. Em destaque na Fogão a gás butano Teka E 60.3 4G AI AL BUT, as grelhas esmaltadas de grande resistência, a segurança por termopar integrada em cada queimador e a superfície em inox de fácil limpeza. Ainda em evidência, o acendedor elétrico integrado no queimador com acionamento em cada comando, oferecendo-lhe maior comodidade utilização.0</p>
      
        
    </div>
     <a href="li3.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >


      <div class="row">
   <div class="card">
    <img class="card-img-top" src="fog4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Fogão de Indução TEKA IBW 64010 TTC  </h5>
A Fogão Teka IBW 64010 TTC apresenta um painel de indução com características inovadoras. O painel de comando TouchControl permite ajustar as zonas de cocção com uma ligeira pressão do dedo e, com recurso à função powerBoost, que aumenta a potência em até 50%, permitindo-lhe economizar 35% do tempo. Também em destaque nesta Fogão Teka IBW 64010 TTC, o painel de comando digital, 9 níveis de potência.     
      
    </div>
     <a href="li4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="fog5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Fogão de Indução BALAY 3EB861LR </h5>
      <p class="card-text">A Fogão vitrocerâmica de indução Balay 3EB861LR integra quatro zonas de indução rápida - duas zonas de 18 cm e duas de 15 cm de diâmetro. O painel de controlo Touch Control Profissional (+/-) simples e direto caracteriza-se pelos seus 17 níveis de potência em cada zona, mas também por funções como: Memória; Início Automático (identificação da zona); programação de tempo de confeção para cada zona e alarme com duração de aviso regulável.</p>
      
      
    </div>
     <a href="li5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="fog6.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Fogão de Indução WHIRLPOOL WF S0160 NE WCOL </h5>
      <p class="card-text">Uma nova interface de usuário com botões dedicados para cada zona de cozinhar. Cada conjunto de comandos é indicado na posição correspondente na superfície da Fogão, tornando a sua utilização incrivelmente intuitiva.Configuração automática de níveis de potência. Basta selecionar o método de cozimento no visor e o fogão ajustará automaticamente a potência necessária.
nova zona FlexiSide garante melhor detecção das panelas e uma distribuição de calor mais homogênea para resultados extraordinários. Ocupe o espaço de que necessita, combinando duas zonas de cozinhar.</p>
      
        
    </div>
     <a href="li6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >
       <div class="row">
  <div class="card" >
    <img class="card-img-top" src="fog7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Fogão de Vitrocerâmica INDESIT RI 161 C</h5>
      <p class="card-text">
     
A Fogão vitrocerâmica Indesit RI 161 C, de 60 cm de largura, soma quatro queimadores radiantes, nove níveis de potência e apresenta potência máxima total de 6200 W. Também em destaque nesta Fogão vitrocerâmica Indesit RI 161 C, os comandos táteis Touch Control, o perfil recortado e as luzes indicadoras de calor residual, não esquecendo o bloqueio de segurança para crianças. Por fim, esta Fogão vitrocerâmica Indesit RI 161 C evidencia-se ainda pelo temporizador incorporado.
</p>
      
      
    </div>

     <a href="li7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="fog8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Fogão de Indução BECKEN Flex BIH3302  </h5>
      <p class="card-text">A Fogão elétrica de indução Becken Flex BIH3302 apresenta uma elegante superfície de vidro que soma quatro zonas de indução capazes de se transformar em amplas zonas flexíveis que lhe permitem cozinhar em grande e de diversas formas, com recipientes de maior dimensão. Também em destaque nesta Fogão elétrica de indução Becken Flex BIH3302, a elevada potência máxima total de 7000 W, os práticos e sensíveis comandos táteis Touch Control frontais e o bloqueio de segurança, que evita o uso indevido da Fogão, não esquecendo o útil temporizador. Espaço de encastre (largura x profundidade): 56 x 49 cm. Dimensões (AxLxP): 5,2 x 59 x 52 cm. Peso de 8,7 kg.</p>
      
      
    </div>
     <a href="li8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="fog9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Fogão de Indução BOSCH PUE645BB1E</h5>
      <p class="card-text">A Fogão de indução Bosch PUE645BB1E soma quatro zonas de indução e permite cozinhar de forma rápida, segura e sempre com baixo consumo de energia, destacando-se pelo controlo tátil TouchSelect, que permite a seleção da zona desejada e o fácil ajuste do nível pretendido, e pela função PowerBoost em todas as zonas para até 50% mais potência e aquecimento rápido. A Fogão de indução Bosch PUE645BB1E evidencia-se também pelo temporizador com função de desligamento automático, sendo que a zona de cozedura se desliga assim que o tempo programado termina. Além de rapidez, precisão, segurança, limpeza fácil e baixo consumo energético, esta Fogão de indução Bosch PUE645BB1E conta com uma moldura plana em inox à volta da Fogão, perfeita para integrar nos nichos existentes. Por fim, sublinhem-se os 17 níveis de potência, o sinal sonoro de fim de tempo e as funções QuickStart e Restart, não esquecendo a deteção do recipiente e a limitação da potência da Fogão.  </p>

    </div>
     <a href="li9.php" class="btn btn-primary">Ver
      Mais</a>
  </div>

</div>

                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos liui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>