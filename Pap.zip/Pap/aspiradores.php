<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;

}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 35%;
}

div.card {
  padding: 15px;
  text-align: center;

}
div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.html" >
          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Aspiradores</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 
        <div class="container" >
          <div class="row">

       

         
  <div class="card">
    <img class="card-img-top" src="asp1.jpg"  ">
    <div class="card-body">
      <h5 class="card-title" >Aspirador com Saco BECKEN Pet Bvc4397 </h5>
      <p class="card-text" >A nova gama de aspiradores Becken Ecológicos foi criada para todos os tipos de chão e com uma pega de transporte para que o possa levar para qualquer lado da forma mais fácil. O BCV4397, com uma capacidade de 3 L, possui um sistema SuperSilent, silencioso, e uma escova PET, perfeita para quem tem animais.</p>

    
    </div>
    <a href="asp1.php" class="btn btn-primary">Ver Mais</a>
  </div>
  



  <div class="card" >
    <img class="card-img-top" src="asp2.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aspirador com Saco BOSCH BGL3HYG</h5>
      <p class="card-text">O aspirador de saco Bosch BGL3HYG apresenta uma estrutura compacta e discreta, com pega de transporte e quatro rodas giratórias, sendo fácil de mover por toda a habitação. Este aspirador Bosch BGL3HYG integra tecnologia QuattroPower, garantindo melhores resultados com consumo energético mínimo, inserindo-se assim na . Destaque para o inovador sistema UltraAllergy de tripla ação, que combina vários filtros para assegurar que pó, ácaros e outros resíduos passíveis de causar alergias são recolhidos e filtrados. Também em evidência neste aspirador Bosch BGL3HYG, o saco de pó XL substituível, com capacidade líquida de 4 litros e tecnologia PowerProtect, que mantém os elevados níveis de desempenho, mesmo com o saco praticamente cheio. Outras características relevantes: potência regulável; filtro HEPA lavável; bocais substituíveis adaptados a diferentes superfícies; raio de ação de 10 metros; indicador de substituição do saco; nível máximo de ruído de 77 dB; pedal para recolha de cabo de alimentação; tubo telescópico.</p>
      
      
    </div>
     <a href="asp2.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="asp3.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aspirador com Saco AEG VX4-1-EB Efficiency</h5>
      <p class="card-text">O aspirador com saco AEG VX4-1-EB é um equipamento doméstico de ótima fiabilidade, desenhado para proporcionar uma limpeza mais eficiente da habitação. Compacto e ergonómico, este aspirador AEG VX4-1-EB possui largas rodas de borracha e uma pega de transporte que facilitam a deslocação pela casa e permitem a limpeza das várias divisões. Com motor Power Inverter e 750 W de potência máxima, o aspirador AEG VX4-1-EB , garantindo um excelente aproveitamento da energia. Outras características relevantes: filtro do motor e filtro Hygiene lavável; tubo metálico telescópico; pedais On/Off e de recolha do cabo de alimentação; raio de ação de 7,5 metros; escova principal DustPro; compatibilidade com sacos S-Bag com capacidade líquida de 3 litros; regulador de potência. Garantia de dois anos.
</p>
      
        
    </div>
     <a href="asp3.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
</div>
</div>
<br>
        </div>
        <div class="container" >


      <div class="row">
        
  <div class="card" >
    <img class="card-img-top" src="asp4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aspirador Robô IROBOT Roomba 966 </h5>
      <p class="card-text">Chão mais limpo. Todos os dias. Basta pressionar um botão. O robot aspirador Roomba® mantém o chão da sua casa limpo todos os dias, para que possa focar-se noutras tarefas do dia-a-dia. O pó e a sujidade diários podem tornar a tarefa de manter a casa limpa interminável. Conheça o iRobot® Robot Aspirador Roomba® 966, o seu parceiro para uma casa mais limpa. Composto por sensores inteligentes e um poderoso sistema de limpeza, o robot aspirador Roomba® trata da sujidade, pó e pelos de animais. O robot aspirador Roomba® 966 com ligação Wi-Fi utiliza 5 vezes* mais poder de sucção para uma limpeza profunda. Navega sem dificuldade por todo o piso da sua casa, recolhe pontos de localização e recarrega-se automaticamente se necessário, até que a limpeza esteja concluída. Com a aplicação iRobot HOME pode limpar e agendar a partir de onde e quando quiser.</p>
      
      
    </div>
     <a href="asp4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="asp5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aspirador Robô IROBOT Roomba 980</h5>
      <p class="card-text">O sistema de navegação com localização visual iAdapt® 2.0 ajuda o Roomba® 980 a navegar de modo eficiente e sem problemas por todo o piso da sua casa, controlando a sua posição, utiliza um conjunto completo de sensores para se adaptar aos obstáculos e móveis da vida real. O perfil baixo do Roomba® permite-lhe limpar por baixo da maioria dos móveis e rodapés, pelo que a sujidade não tem onde se esconder. Os sensores de deteção de inclinações permitem que o Roomba evite escadas e outros desníveis perigosos. O Roomba® 980 funciona de modo contínuo durante um máximo de duas horas, após o que se recarrega e reinicia automaticamente a limpeza até terminar a tarefa.</p>
      
      
    </div>
     <a href="asp5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="asp6.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aspirador Robô IKOHS Netbot S15</h5>
      <p class="card-text">Robô aspirador profissional 4 em 1: varre, aspira, passa o pano e esfrega, tudo em um e em todos os tipos de superfícies. Com a nossa APP pode programar, parar, aplicar funções e tempos de limpeza e ter o controlo do robô de limpeza a partir de qualquer lugar. Inclui uma inovadora tecnologia de navegação inteligente SmartGYROSCOPE com sensores giroscópicos que, ao contrário de outros robôs de limpeza, permite mapear enquanto limpa e rotacionar para cobrir o 100% das superfícies, evitando colisões e quedas. Agora pode ver no mapa da APP, onde ele limpou o aspirador inteligente e o que resta para completar toda a superfície. Além disso, graças ao seu sistema WI-FI com reconhecimento de voz, é compatível com os sistemas, ALEXA e Google Home.</p>
      
        
    </div>
     <a href="asp6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
</div>
</div>
<br>
        </div>
        <div class="container">
             <div class="row">
 
  <div class="card" >
    <img class="card-img-top" src="asp7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aspirador Vertical Rowenta RH 6751 WO</h5>
      <p class="card-text">
      Aspirador vertical sem saco RH 6751 WO Rowenta, com autonomia até 45 minutos, tempo de recarga até 5 horas e 0.6 litros de capacidade do depósito de pó.O aspirador vertical RH 6751 WO da Rowenta é um aspirador vertical sem fios com um mini aspirador integrado, para poupar tempo e obter máxima conveniência enquanto aspira. Este aspirador combina uma escova rotativa motorizada com iluminação LED integrada e uma bateria de lítio para uma elevada autonomia. Para além de todas estas características tem ainda um design ultra leve para uma sessão de aspiração rápida e sem qualquer esforço.A pega rebatível e a posição de descanso vertical facilitam a arrumação e oferecem máximo conforto de uso.O aspirador vertical RH 6751 WO dispõe de 2 velocidades, e nível de ruído de 79 dB. Garantia de 2 anos.</p>
      
      
    </div>
     <a href="asp7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >


 
    <img class="card-img-top" src="asp8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aspirador Vertical Bosch 2 em 1 BBHF220 </h5>
      <p class="card-text">O aspirador vertical sem saco Bosch 2 em 1 BBHF220, garante uma performance de aspiração potente e silenciosa com um elevado nível de comodidade. com longa autonomia de até 40 minutos e tempo de carregamento de cinco horas. O aspirador vertical sem fio Bosch BBHF220 é portátil e de grande flexibilidade, uma vez que integra dois aspiradores (vertical e de mão).Sempre à mão aspirador sem saco.</p>
      
      
    </div>
     <a href="asp8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="asp9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aspirador Vertical AEG CX7-2-35O 18V</h5>
      <p class="card-text">Aspirador Vertical AEG CX7-2-35O 18V, apresenta um nível de ruído de 79 dB e autonomia máxima de 35 min, capacidade do depósito do pó é de 0,5 litros.Máxima flexibilidade e design funcional! Seja para limpar uma área grande ou um sítio difícil, o CX7 X Flexibility resolve o problema. O mini-aspirador de mão limpa sem esforço, seja a mesa da cozinha, os móveis ou o interior do carro.O CX7-2-35O da AEG carateriza-se por ser um aspirador vertical que demora 4 horas a carregar a bateria. Com filtro duplo e bateria de lítio TurboPower. Rotação de 180º e iluminação LED Dustpotter que garante uma experiência de limpeza bastante eficaz.</p>
      
        
    </div>
     <a href="asp9.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
</div>
</div>


                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos aqui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>