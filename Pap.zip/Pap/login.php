<!DOCTYPE html>
<head>
  <meta charset="UTF-8" />
  <title></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <link rel="stylesheet" type="text/css" href="style.css" />

</head>
<body>

<body background="fundo.jpg">
  <div class="container" >
    <a class="links" id="paracadastro"></a>
    <a class="links" id="paralogin"></a>
     
    <div class="content">      
  
      <div id="login">
        <form method="post" action="processa_login.php"> 
          <h1>Login</h1> 
          <p> 
            <label for="nome">Nome</label>
            <input id="nome" name="nome" required="required" type="text" placeholder="ex. contato@htmlecsspro.com"/>
          </p>
         
           
          <p> 
            <label for="email">E-mail</label>
            <input id="email" name="email" required="required" type="text"  required="required" type="text" placeholder="ex. contato@htmlecsspro.com"/> 
          </p>
           <p> 
            <label for="palavra_passe">Palavra Passe</label>
            <input id="palavra_passe" name="palavra_passe" 
            required="required" type="password" placeholder="ex. senha" 
            />

          </p>
           
          <p> 
            <input type="checkbox" name="manterlogado" id="manterlogado" value="" /> 
            <label for="manterlogado">Manter-me logado</label>
          </p>
           
          <p> 
            <input type="submit" value="Login" /> 
          </p>
           
          <p class="link">
            Ainda não tem conta?
            <a href="#paracadastro">Registe-se</a>
          </p>
        </form>
      </div>
 
    
      <div id="cadastro">
        <form method="post" action="create.php"> 
          <h1>Registar</h1> 
           
          <p> 
            <label for="nome">Nome</label>
            <input id="nome" name="nome" required="required" type="text" placeholder="nome" />
          </p>
           
          <p> 
            <label for="email">Email</label>
            <input id="email" name="email" required="required" type="email" placeholder="contato@htmlecsspro.com"/> 
          </p>
           
          <p> 
            <label for="palavra_passe">Palavra Passe</label>
            <input id="palavra_passe" name="palavra_passe" required="required" type="password" placeholder="ex. 1234"/>
          </p>
          <br>
           
          <p> 
            <input type="submit" value="Registar"/> 
          </p>
          
          <br>
           
          <p class="link">  
            Já tem conta?
            <a href="#paralogin"> Ir para Login </a>
          </p>
        </form>
      </div>
    </div>
  </div>  
</body>
</html>