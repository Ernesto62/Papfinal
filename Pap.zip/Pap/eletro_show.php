<?php 
if ($_SERVER['REQUEST_METHOD']=="GET") {

	if (!isset($_GET['eletrodomesticos']) || !is_numeric($_GET['eletrodomesticos'])) {
		echo '<script>alert("Erro ao abrir eletro");</script>';
		echo 'Aguarde um momento.A reencaminhar página';
		header("refresh:5, url=index.php");

	}
	$ideletrodomesticos=$_GET['eletrodomesticos'];

	$con=new mysqli("localhost","root","","eletrodomesticos");

	if($con->connect_errno!=0){
		echo 'Ocorreu um erro no acesso á base de dados.<br>'.$con->connect_error;
		exit;
	}
	else{
		$sql='select * from eletrodomesticos where id=? ';
		$stm = $con->prepare($sql);
		if($stm!=false){
			$stm->bind_param('i',$ideletrodomesticos);
			$stm->execute();
			$res=$stm->get_result();
			$eletro=$res->fetch_assoc();
			$stm->close();
		}
		else{
			echo'<br>';
			echo ($con->error);
			echo'<br>';
			echo 'Aguarde um momento.A reencaminhar página';
			echo'<br>';
			echo ("refresh:5; url=index.php");
			}
		}

	
}
?>
<!DOCTYPE html>

<html>
<head>
	<meta charset="ISO=8859-1">
	<title>Detalhes</title>
</head>
<body>
	<h1>Detalhes do eletrodomesticos</h1>
	<?php
	if (isset($eletro)) {
		echo'<br>';
		echo $eletro['descricao'];
		echo'<br>';
		echo utf8_encode($eletro['preco']);
		echo'<br>';
		echo $eletro['eletrodomestico'];
		echo'<br>';
		echo $eletro['categoria'];
		echo'<br>';
		echo $eletro['imagem'];
		echo'<br>';
		
	}
	else{
		echo '<h2>Parece que o eletrodomesticos selecionado não existe.<br>Confirme a sua seleção.</h2>';
	}
	?>

</body>
</html>