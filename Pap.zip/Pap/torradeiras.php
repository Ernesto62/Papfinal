<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;

}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 30%; 
}

div.card {
  padding: 15px;
  text-align: center;

}
div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.html" >
          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Torradeiras</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 

        <div class="container">
             <div class="row">

         
  <div class="card">
    <img class="card-img-top" src="tor1.jpg"  ">
    <div class="card-body">
      <h5 class="card-title" >Torradeira BOSCH Tat4P424 Designli </h5>
      <p class="card-text" >Torradeira em aço inoxidável. 2 aberturas para duas fatias de pão. Regulação do grau de tostagem. Sensor electrónico para uma tostagem uniforme. Centragem automática do pão.</p>

    
    </div>
    <a href="tor1.php" class="btn btn-primary">Ver Mais</a>
  </div>


  <div class="card" >
    <img class="card-img-top" src="tor2.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Torradeira RUSSELL HOBBS 23334-56</h5>
      <p class="card-text">A elegante torradeira Russell Hobbs Classic Cream 23334-56 possui controlo inteligente de torragem ajustável para que possa fazer a torrada ao seu gosto. Apresenta ranhuras mais largas para acomodar fatias mais espessas, tornando-a ideal para torrar pãezinhos. Com a função de levantamento elevado, poderá observar o estado de torragem das fatias sem ter de cancelar o ciclo. Destaca-se também pela tecnologia de torragem mais rápida, pela função de torragem de pão congelado e pela estrutura para aquecimento de pãezinhos. Outras características: tabuleiro de recolha de migalhas; estrutura em aço inox; funções de descongelar e cancelar; compartimento para cabo; pés antiderrapantes; 1100 W de potência. Garantia de dois anos.</p>
      
      
    </div>
     <a href="tor2.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="tor3.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Torradeira SMEG Anni 50 TSF02PKEU (Rosa - 1500 W)</h5>
      <p class="card-text">A torradeira Smeg TSF02PKEU da série clássica Anni 50 é mais do que um eletrodoméstico muito útil. Esta peça de design desenvolvida em parceria com o atelier Deepdesign, com duas fendas longas e potência de 1500 W, apresenta um corpo em chapa de aço com moldagem intensa. Destaca-se pela autocentragem das grelhas, pelos seis níveis de tostagem e pelas funções Reaquecer, Descongelar, Cancelar e Bagel. Outras características relevantes: gaveta de migalhas em aço inoxidável removível; fixadores para enrolar o cabo; pés antiderrapantes; desligamento automático; paredes frias. Garantia de dois anos.
      
        
    </div>
     <a href="tor3.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
     <div class="container">
             <div class="row">
  <div class="card" >
    <img class="card-img-top" src="tor4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Torradeira KENWOOD TTM470 </h5>
      <p class="card-text">A torradeira Kenwood TTM470 é perfeita para pequenos-almoços ou lanches completos. Com capacidade para quatro fatias e controlo de ajuste da tostagem, destaca-se ainda pela função de descongelação e pela elevação automática das fatias dos pães, não esquecendo a função cancelar e as duas aberturas largas para diversas espessuras de pão. Mais que um aparelho, integra a decoração da sua cozinha graças a um design exclusivo. Outras características: corpo em aço inoxidável; potência de 1500 W; sistema de centragem automática da torrada; armazenamento do cabo; botões iluminados; tabuleiro de migalhas amovível; desligamento automático; paredes frias.</p>
      
      
    </div>
     <a href="tor4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="tor5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Torradeira PHILIPS HD2639/90</h5>
      <p class="card-text">A torradeira Philips HD2639/90 apresenta duas fendas que asseguram a preparação de óptimas tostas, tanto altas como finas, graças à abertura extra-larga e ao acessório para tostas com abertura expansível. Independentemente da tosta ser fina ou alta, é sempre mantida perfeitamente centrada para um resultado de torragem uniforme. Em destaque, a estrutura incorporada para aquecer pães individuais ou pastéis, o tabuleiro para migalhas amovível de limpeza fácil e o controlo de torragem com sete níveis ajustáveis. Outras características: proteção adicional de desligamento automático; botão de cancelamento da torragem; parede fria ao toque; funções de aquecimento e descongelamento para torrar pão congelado de uma só vez.</p>
      
      
    </div>
     <a href="tor5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="tor6.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Torradeira TAURUS MyToast Duplo</h5>
      <p class="card-text">A torradeira Taurus MyToast Duplo, com duas fendas extralargas de 262 mm de comprimento e 32 mm de largura, tosta todo o tipo de pão à potência máxima de 1450 W. Além do preciso regulador do tempo de aquecimento, a torradeira Taurus MyToast Duplo soma três funções (descongelar, reaquecer e cancelar o aquecimento) e destaca-se também pela elevação extra para fácil saída da torrada ou de pedaços de pão. Ainda em evidência nesta torradeira Taurus MyToast Duplo, o tabuleiro para migalhas e o prático compartimento para arrumação do cabo. Outras características relevantes: seis níveis de tostagem; iluminação LED azul nos controlos; pés antiderrapantes; paredes frias.</p>
      
        
    </div>
     <a href="tor6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
        <div class="container">
             <div class="row">
  <div class="card" >
    <img class="card-img-top" src="tor7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Torradeira ARIETE 00C015513AR0 </h5>
      <p class="card-text">
     
Torradeira ARIETE 00C015513AR0 (Creme - 810 W)
A torradeira Ariete Vintage 0155TP de cor creme soma duas fendas apresenta um painel frontal de ajuste da tostagem com ejeção automática do pão. Além do temporizador de tostagem ajustável em seis níveis, a torradeira Ariete Vintage 0155TP destaca-se também pelas paredes frias, pelos botões de acionamento da função de cancelamento e pelas funções de aquecimento e descongelação, não esquecendo a centragem automática do pão. Também em evidência, o tabuleiro amovível de recolha de migalhas. A torradeira Ariete Vintage 0155TP acrescenta, além de tudo isto, o estilo que faz a diferença na sua cozinha. Outras características relevantes: potência de 810 W; enrolador de cabo; cabo de 90 cm de comprimento; pés antideslizantes.</p>
      
      
    </div>
     <a href="tor7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="tor8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Torradeira ORBEGOZO TO 3010 </h5>
      <p class="card-text">A torradeira de duas fendas Orbegozo TO 3010 é a peça que lhe falta na cozinha para completar o puzzle dos pequenos-almoços inesquecíveis. Com 750 W de potência, a torradeira Orbegozo TO 3010 apresenta as funções de descongelação, aquecimento e paragem imediata, destacando-se também pela grelha superior para aquecimento de pãezinhos e pelo desligamento automático, não esquecendo a gaveta para migalhas. Ainda em evidência nesta torradeira Orbegozo TO 3010, as paredes frias ao toque e as três lâmpadas LED de controlo. Outras características relevantes: enrolador de cabo; termóstato de regulação precisa em cinco posições; pés antideslizantes.</p>
      
      
    </div>
     <a href="tor8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="tor9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Torradeira PROFICOOK Taz 1110</h5>
      <p class="card-text">A Proficook TAZ1110, uma compacta torradeira de duas entradas e com potência que pode oscilar entre 860 e 1050 W, apresenta-se com revestimento total em inox, ranhuras de entrada de fatias de 40 mm e diversos atributos essenciais nesta gama de produtos, entre os quais sublinhamos as paredes frias, os pés antideslizantes ou o sistema de desligamento automático. As pegas são resistentes ao aquecimento e osuporte com duas pinças inox possibilita a fácil remoção das fatias. No que respeita a funções, inclui centragem automática, descongelação/reaquecimento e Quick Stop. Outras características: gaveta para migalhas; enrolador de cabo. </p>
      
        
    </div>
     <a href="tor9.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>


                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos aqui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>