<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
    
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;
}
       h2 {
        color: #007aff;
       }
  </style>

  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff;">
        <a class="navbar-brand" href="index.php" >
          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes." style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
             <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Produtos</h1>
                                 <br>
                                
                                  
       
            
                

            </div>
        </div>


       
             <div class="container">
                <hr>

            <div class="row">
                
                <div class="col-md-3">
                    <h2 style="text-align:center">Aspiradores
                </h2>
                
               
                <p><a href="eletro.php?categoria=aspirador"><img src="si111.jpg" width="200" height="200"></a></p>
            </div>
               <div class="col-md-3">
                    <h2 style="text-align:center"style="text-align:center">Torradeiras
                </h2>
                
               
                <p><a href="eletro.php?categoria=torradeira"><img src="sin.png" width="200" height="200"></a></p>
            </div>
                <div class="col-md-3">
                    <h2 style="text-align:center">Aquecedores
                </h2>
                
               
                <p><a href="eletro.php?categoria=aquecedor"><img src="si3.jpg" width="200" height="200"></a></p>
            </div>
              <div class="col-md-3">
                    <h2 style="text-align:center">Secadores
                </h2>
                
               
                <p><a href="eletro.php?categoria=secador"><img src="si4.png" width="200" height="200"></a></p>
            </div>

        </div>
        
        <hr>
        

          <div class="container">
                
            <div class="row">
                
                <div class="col-md-3">
                    <h2 style="text-align:center">Micro-ondas
                </h2>
                <br>

                
               
                <p><a href="eletro.php?categoria=microonda"><img src="si5.jpg" width="200" height="200"></a></p>
            </div>
               <div class="col-md-3">
                    <h2 style="text-align:center">Maquinas de Café
                </h2>
                
               
                <p><a href="eletro.php?categoria=maquinadecafe"><img src="si6.jpg" width="200" height="200"></a></p>
            </div>
                <div class="col-md-3">
                    <h2 style="text-align:center">Batedeiras
                </h2>
                <br>
                
               
                <p><a href="eletro.php?categoria=batedeira"><img src="si7.png" width="200" height="200"></a></p>
            </div>
              <div class="col-md-3">
                    <h2 style="text-align:center">Cafeteiras
                </h2>
                <br>
                
               
                <p><a href="eletro.php?categoria=cafeteira"><img src="si7.jpg" width="200" height="200"></a></p>
            </div>

        </div>
        <hr>
        <div class="container">
                
            <div class="row">
                
                <div class="col-md-3">
                    <h2 style="text-align:center">Frigorificos
                </h2>
                
               
                <p><a href="eletro.php?categoria=frigorifico"><img src="si9.png" width="200" height="200"></a></p>
            </div>
               <div class="col-md-3">
                    <h2 style="text-align:center">Liquidificadores
                </h2>
                
               
                <p><a href="eletro.php?categoria=liquidificadore"><img src="si99.jfif" width="200" height="200"></a></p>
            </div>
                <div class="col-md-3">
                    <h2 style="text-align:center">Fornos
                </h2>
                
               
                <p><a href="eletro.php?categoria=forno"><img src="si11.jpg" width="200" height="200"></a></p>
            </div>
              <div class="col-md-3">
                    <h2 style="text-align:center">Fogões
                </h2>
                
               
                <p><a href="eletro.php?categoria=fogao"><img src="si12.jpg" width="200" height="200"></a></p>
            </div>

        </div>
        
        <hr>
        
        <div class="container">
                
            <div class="row">
                
                <div class="col-md-3">
                    <h2 style="text-align:center">Maquina de Lavar a Louça
                </h2>
                
               
                <p><a href="eletro.php?categoria=maquindadelavaralouca"><img src="si14.png" width="200" height="200"></a></p>
            </div>
               <div class="col-md-3">
                    <h2 style="text-align:center">Maquina de Lavar a Roupa
                </h2>
                
               
                <p><a href="eletro.php?categoria=maquinadelavararoupa"><img src="si13.png" width="200" height="200"></a></p>
            </div>
                <div class="col-md-3">
                    <h2 style="text-align:center">Maquina de Secar
                </h2>
                
               
                <p><a href="eletro.php?categoria=maquinadesecar"><img src="si15.png" width="200" height="200"></a></p>
            </div>
              <div class="col-md-3">
                    <h2 style="text-align:center">Ferros de Engomar
                </h2>
                
               
                <p><a href="eletro.php?categoria=ferrodegomar"><img src="si2.jpg" width="200" height="200"></a></p>
            </div>

        </div>
        
        <hr>
       

                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!DOCTYPE html>
<html>

<head>
    <title>Programador Viking | Rodapé Branco Básico</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
</head>

<body>
    <div class="content">
    </div>
    <footer id="myFooter">
        <div class="container">
            <ul>
                <li><a href="https://programadorviking.com.br/">Informações da Empresa</a></li>
                <li><a href="https://programadorviking.com.br/">Contato</a></li>
                <li><a href="https://programadorviking.com.br/">Blog</a></li>
                <li><a href="https://bit.ly/front-end-curso-completo-promocao-01">Cursos</a></li>
            </ul>
            <p class="footer-copyright">© 2019 Copyright - Programador Viking</p>
        </div>
        <div class="footer-social" align="center">
            <a href="https://programadorviking.com.br/" class="social-icons"><i class="fa fa-facebook"></i></a>
            <a href="https://programadorviking.com.br/" class="social-icons"><i class="fa fa-instagram"></i></a>
            <a href="https://programadorviking.com.br/" class="social-icons"><i class="fa fa-youtube"></i></a>
            <a href="https://programadorviking.com.br/" class="social-icons"><i class="fa fa-twitter"></i></a>
                <a href="https://programadorviking.com.br/" class="social-icons"><i class="e0be"></i></a>

        </div>
    </footer>
   
</body>

</html>


    </main>
  </body>
</html>
