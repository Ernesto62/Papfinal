<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;


}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 35%;
}

div.card {
  padding: 15px;
  text-align: center;
}

div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.html" >
          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Aquecedores</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 
   <div class="container">
             <div class="row">

         
  <div class="card">
    <img class="card-img-top" src="aq1.jpg"  ">
    <div class="card-body">
      <h5 class="card-title" >Aquecedor Emissor Térmico ROINTE DNB1430RAD </h5>
      <p class="card-text" >O emissor térmico Rointe DNB1430RAD foi concebido com atenção aos mais ínfimos detalhes. O seu inovador design curvo com fechos laterais Slim Line Aluminium, o painel de controlo tátil retroiluminado e as tecnologias avançadas Fuzzy Logic, Energy Control e E-Life Technology fazem do radiador Rointe DNB1430RAD um produto estrela da marca. Graças à sua tecnologia Fuzzy Logic Energy Control, a potência média consumida corresponde a apenas 38% da sua potência, sendo que o design curvo com fechos laterais de ambos os lados confere ao produto acabamento compacto e aparência consistente. Também em destaque, a eletrónica multicamadas de montagem superficial com microcontroladores incorporados duplos Rointe XLP8 e XLP16 Extreme Low Power, bateria de lítio de longa duração e Triac como elemento de corte. Os seus 110 W por elemento proporcionam transferência térmica equilibrada, comparativamente a outros radiadores do mercado que consomem entre 125 e 160 W por elemento, sendo assim menos eficientes. Além disso, o emissor térmico Rointe DNB1430RAD conta com tecnologia E-Life que permite gerir o aquecimento a partir da Internet de forma simples e com controlo individual para cada radiador. Ainda em evidência, o ecrã TFT de 1,77” de última geração com alto contraste para a visualização ideal a partir de qualquer ângulo de visualização. Outras características: módulo Wi-Fi; 13 elementos; potência nominal de 1430 W; potência efetiva de 543 W.</p>

    
    </div>
    <a href="aq1.php" class="btn btn-primary">Ver Mais</a>
  </div>


  <div class="card" >
    <img class="card-img-top" src="aq2.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aquecedor Emissor Térmico BECKEN BTE3512 </h5>
      <p class="card-text">O emissor térmico Becken BTE3512, com potência de 2000 W, apresenta uma ampla superfície de calor, sendo no entanto muito discreto, prático e fino, além de apresentar ótima mobilidade graças às rodas na base. Económico e de fácil transporte, o emissor térmico Becken BTE3512 integra um painel de controlo simples com visor digital e cinco botões de comando, permitindo ajustar a potência e programar o funcionamento. Aqueça rápida, eficiente e facilmente a sua casa com o emissor térmico Becken BTE3512 nos dias mais frios e aprecie o conforto. Garantia de dois anos.A Worten destaca: emissor térmico com potência de 2000 W e rodas na base; painel de controlo intuitivo com visor digital e cinco botões de comando.Este produto é adequado apenas para espaços bem isolados ou utilização ocasional.</p>
      
      
    </div>
     <a href="aq2.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="aq3.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aquecedor Convector IKOHS Heatbox</h5>
      <p class="card-text">Aquecedor convetor de ar HEATBOX da IKOHS. Um eficiente aquecedor ideal para aquecer e aclimatar as divisões de sua casa à temperatura de conforto. A sua tecnologia Quick Confort, unida aos seus 2000W de potência, permite-lhe aquecer em muito pouco tempo qualquer uma das divisões onde o coloque. Qualquer um dos seus 4 modos de funcionamento irá resultar ideal para conseguir um calor imediato. É ultra silencioso graças ao SUBNoise System que incorpora, pelo que apenas irá sentir o agradável calor que o seu ventilador de convecção distribui. Conta com 2 sistemas de segurança: Anti queda e sobreaquecimento, é muito leve e fácil de transportar, para que o possa levar onde mais lhe convenha. Com um desenho clássico mas atualizado, o HEATBOX ficará perfeito em qualquer divisão, ao mesmo tempo que irá dar calidez à sua casa.
      
        
    </div>
     <a href="aq3.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container">
             <div class="row">
  <div class="card" >
    <img class="card-img-top" src="aq4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aquecedor Termoventilador BECKEN BCTH3344 </h5>
      <p class="card-text">O termoventilador cerâmico de torre Becken BCTH3344, com 2000 W de potência, filtro anti-pó e sistema silencioso, foi concebido para utilização em qualquer divisão da casa. Além do sistema de desligamento automático do aparelho em caso de queda acidental, mantendo as configurações previamente definidas, o termoventilador cerâmico de torre Becken BCTH3344 destaca-se também pelo filtro anti-pó para uma saída de ar mais limpa, pela base giratória cuja estrutura oscilante ajuda a aquecer a divisão de forma mais uniforme e pela tecnologia cerâmica altamente eficiente e segura graças ao elemento de cerâmica que autorregula a saída do calor de acordo com o aumento de temperatura. Ainda em evidência neste termoventilador cerâmico de torre Becken BCTH3344, o painel de controlo mecânico com dois comandos rotativos no topo e a opção por dois níveis de potência. Outras características: indicador luminoso; pega de transporte. Dimensões (AxLxP): 72 x 23,8 x 28 cm. Peso de 3,5 kg. Garantia de dois anos.A Worten destaca: termoventilador cerâmico de torre com 2000 W de potência, filtro anti-pó e base giratória com movimento oscilante; elemento de cerâmica; painel de controlo mecânico com dois comandos rotativos no topo; dois níveis de potência.</p>
      
      
    </div>
     <a href="aq4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="aq5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aquecedor Termoventilador FLAMA 2304FL </h5>
      <p class="card-text">O termoventilador cerâmico Flama 2304FL, com potência de 1500 W, apresenta termóstato regulável, sinalizador luminoso de funcionamento e destaca-se pela integração de tecnologia PTC, bem como pela proteção automática de sobreaquecimento. Soma dois níveis de aquecimento (ar morno e ar quente) e conta com sistema de segurança e ventoinha silenciosa. Ainda em evidência, a útil pega de transporte e o elemento de aquecimento em cerâmica. Garantia de dois anos.</p>
      
      
    </div>
     <a href="aq5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="aq6.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aquecedor Termoventilador TRISTAR KA-5037</h5>
      <p class="card-text">Aqueça-se e aqueça a casa neste Inverno com o termoventilador portátil Tristar KA5037, que incorpora uma asa para fácil transporte. Este ventilador fácil de usar e fácil de mover, com posição de ventilação de ar frio, destaca-se pelo fiável termóstato regulável, pelas três posições de ventilação e pela proteção contra sobreaquecimento. Outras características relevantes: potência de 2000 W; voltagem de 220 a 240 V; frequência de 50 a 60 Hz; cabo de alimentação de aproximadamente 140 cm; interruptor luminoso.</p>
      
        
    </div>
     <a href="aq6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
         <div class="container">
             <div class="row">
  <div class="card" >
    <img class="card-img-top" src="aq7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aquecedor Termoventilador TAURUS Tropicano 2400 </h5>
      <p class="card-text">
     
O termoventilador Taurus Tropicano 2400, com 2400 W de potência, não o aquece só a si e à família nos dias mais frios, mas também a casa. Destaca-se pelas três posições de climatização (frio/calor), para maior amplitude de ajuste térmico, e pelo termóstato regulável. Também em evidência, a pega de transporte que o torna muito portátil e prático, e o facto de ser silencioso. Peso bruto de 1,21 kg. Garantia de dois anos.
</p>
      
      
    </div>
     <a href="aq7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="aq8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aquecedor Termoventilador TRISTAR KA-5039  </h5>
      <p class="card-text">O termoventilador portátil Tristar KA5039 é, além de fácil de usar, fácil de mover. Com posição de ventilação de ar frio, soma uma potência máxima de 2000 W e apresenta três posições ajustáveis. Destaca-se pelo termóstato regulável, pela proteção contra sobreaquecimento e pela presença de um interruptor luminoso. Outras características relevantes: pega de transporte; voltagem de 220-240 V; frequência de 50-60 Hz. Garantia de dois anos.</p>
      
      
    </div>
     <a href="aq8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="aq9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Aquecedor Infravermelho TRISTAR KA-5024</h5>
      <p class="card-text">O aquecedor de halogéneo Tristar KA-5024, com potência máxima de 1200 W, apresenta três posições de aquecimento (400, 800 e 1200 W) e a funcionalidade de oscilação, pelo que é ideal para aquecer rápida e confortavelmente uma divisão média em noites ou dias mais frios. As três posições ajustáveis e o movimento oscilante do corpo deste aquecedor de halogéneo Tristar KA-5024 asseguram a distribuição uniforme de calor de modo imediato num espaço ou local específico. Também em destaque neste aquecedor de halogéneo Tristar KA-5024, o sistema de proteção de queda, o interruptor On/Off e a prática pega de transporte, que lhe confere ótima portabilidade e fácil transporte. Outras características relevantes: quatro barras de aquecimento. </p>
      
        
    </div>
     <a href="aq9.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>


                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos aqui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>