<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
    .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;


}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 35%;
}

div.card {
  padding: 15px;
  text-align: center;
}

div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.php" >

          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Cafeteiras</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 
         <div class="container" >
          <div class="row">




         
  <div class="card">
    <img class="card-img-top" src="eira1.jpg"  ">
    <div class="card-body">
      <h5 class="card-title" >Cafeteira Elétrica DELONGHI EMKM6 Alicia Plus   </h5>
      <p class="card-text" >A Alicia EMKM6 da DeLonghi é uma máquina de café sem fios com base rotativa a 360º que apresenta capacidade para três ou seis chávenas e um design elegante e compacto. O controlo manual facilita a gestão e a função de desligamento automático mantém a temperatura do café, enquanto a base independente fria permite a sua colocação em qualquer superfície com toda a segurança e conforto. Com indicador do nível de água e luz piloto, a tampa e depósito transparentes são de fácil limpeza. Potência de 450 W. </p>

    
    </div>
    <a href="eira1.php" class="btn btn-primary">Ver Mais</a>
  </div>


  <div class="card" >
    <img class="card-img-top" src="eira2.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Cafeteira de Prensa BODUM Aço Inox 1 L Preto </h5>
      <p class="card-text">A Cafeteira BRAZIL incorpora o lema da BODUM®: um bom design não tem de ser caro. Afinal, queremos proporcionar a todos a possibilidade de preparar uma excelente chávena de café de forma ecológica: adicione café moído, água quente e prense. Não são necessários filtros de papel nem copos de plástico.
A Cafeteira BRAZIL possui um cafeteira em vidro de borossilicato (um critério para os êmbolos de todas as Cafeteiras BODUM®), resistente ao calor, e uma asa e base em polipropileno, que tornam a Cafeteira BRAZIL fácil de usar e limpar.</p>
      
      
    </div>
     <a href="eira2.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="eira3.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Cafeteira BODUM Pour Over 11571-01S </h5>
      <p class="card-text">Esta cafeteira BODUM® estabelece novos padrões na preparação de cafés deliciosos: sem filtros de papel – apenas um sabor puro.A água quente é distribuída lenta e uniformemente sobre o café em pó, permitindo que um sabor rico e um aroma robusto se desenvolvamFiltro permanente de aço inoxidável – não é necessário comprar filtros de papel descartáveisO cafeteira é feito em vidro de borossilicato insípidoA tira removível protege as suas mãos do vidro quenteLavável na máquina de lavar louçaFabricada na Europa
A Cafeteira POUR OVER BODUM® possui um filtro de rede fina em aço inoxidável, pelo que já não é necessário comprar filtros de papel descartáveis. Isso promove o puro desabrochar do sabor – acabaram-se os filtros de papel que retêm os óleos essenciais e os sabores.</p>
      
        
    </div>
     <a href="eira3.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
        <div class="container" >
          <div class="row">
       
  <div class="card" >
    <img class="card-img-top" src="eira4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Cafeteira BODUM Caffettiera 1918-913   </h5>
      <p class="card-text">O típico sistema de prensa das Cafeteiras BODUM®: para um café aromático encorpado.As pernas cromadas da estrutura protegem a superfície de danos causados pelo calor.A estrutura em aço inoxidável cromado oferece uma proteção adicional ao cafeteira de vidro.cafeteira fabricado em vidro de borossilicato, insípido e resistente ao calor, com asa e tampa de plástico para um manuseamento seguro.Ecológica, pois não são necessários filtros de papel nem cápsulas.Fabricada na Europa
A cafeteira de prensa com tampa de plástico CAFFETTIERA não apresenta apenas um estilo clássico, traz também o melhor aroma do seu café e não deixa praticamente nenhum resíduo na sua chávena! Basta adicionar café em pó de moagem grossa e água ente, aguardar 4 minutos e, em seguida, pressionar lentamente o êmbolo para baixo</p>
      
      
    </div>
     <a href="eira4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="eira5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Cafeteira BODUM Kenya 11751-16 </h5>
      <p class="card-text">A cafeteira KENYA, que já deu provas da sua qualidade, oferece a melhor maneira de saborear uma chávena de café: Fácil e rápida de usar, este é o método por excelência se quer preparar corretamente um café. extrairá o máximo de óleos essenciais dos grãos de café moídos, deixando o mínimo de sedimento na sua chávena! Basta adicionar café moído, deitar água bem temperada, mexer, aguardar 3 a 4 minutos e pressionar suavemente o êmbolo para parar a infusão – uma bebida revigorante para dias agitados! Beber café caseiro já não pertence ao passado, mas é um luxo do futuro. A asa e a base protegem o utilizador e qualquer superfície de danos provocados pelo calor – a estrutura protege a cafeteira, feito de vidro de borossilicato ultraleve.</p>
                            
      
    </div>
     <a href="eira5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="eira6.jpg" alt="Card image cap">
    <h1 style='color:#007aff;'><b>|-25%|</b></h1>
    <div class="card-body">
      <h5 class="card-title">Cafeteira Elétrica BECKEN IX BWK1053 </h5>
      <p class="card-text">O cafeteira elétrica Becken LX BWK1053 em inox foi desenvolvido a pensar em si. Com capacidade de 1,7 litro e potência de 1850 a 2200 W, o cafeteira elétrica Becken LX BWK1053 consegue aquecer mais água em menos tempo. O indicador do nível de água, a tampa com fecho e o filtro anti-calcário possibilitam uma utilização mais fácil e adequada para que possa poupar tempo, libertando-o para outras atividades. De design elegante e moderno, este cafeteira elétrica Becken LX BWK1053 é facilmente transportável sempre que precisar. Poderá ainda tirar todas as dúvidas no manual de instruções incluído na embalagem. Dimensões (AxLxP): 21,5 x 16,1 x 22,5 cm. Peso de 1,025 kg. Outras características relevantes: desligamento automático; sistema de segurança; filtro anti-impurezas. Garantia de dois anos.A Worten destaca: cafeteira elétrica com capacidade de 1,7 litro; potência de 1850 a 2200 W; indicador do nível; filtro anti-calcário; desligamento automático; luz piloto.</p>
      
        
    </div>
     <a href="eira6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
        <div class="container" >
          <div class="row">
   
  <div class="card" >
    <img class="card-img-top" src="eira7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Cafeteira Elétrica KENWOOD SJM490 </h5>
      <p class="card-text">
     
O cafeteira térmico Kenwood SJM490, com 2200 W de potência e capacidade de 1,7 litro, facilita a sua vida no momento da preparação de chá, café ou simplesmente para aquecer água de maneira rápida e eficaz sem longas esperas. Com interruptor On/Off e janela para visualização do nível de água, fica a saber perfeitamente para quantas chávenas está a ferver água, o que significa menos desperdício. Concebido para oferecer praticidade e conforto graças a base 360º, conta também com armazenamento do cabo, indicadores de potência iluminados e proteção de cozer a seco. Outras características: indicador do nível de água; tampa de abertura fácil; sem fio; filtro amovível; desligamento automático.

</p>
      
      
    </div>

     <a href="eira7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="eira8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Cafeteira Elétrica FLAMA 716fl   </h5>
      <p class="card-text">O cafeteira elétrica Flama 716FL, com potência de 2200 W e capacidade de 1,7 litro, apresenta uma base destacável (sistema sem fios a 360º), filtro de impurezas e visor de nível de água. Também em destaque, o indicador luminoso de funcionamento, a resistência oculta e o desligamento automático. Outras características relevantes: enrolador de cabo; sistema de segurança.</p>
      
      
    </div>
     <a href="eira8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="eira9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Cafeteira Elétrica BOSCH TWK8611P</h5>
      <p class="card-text">O cafeteira elétrica Bosch TWK8611P, com capacidade de 1,5 litro e potência de 2000 a 2400 W, é perfeito para apreciadores de chá, mas também de design. Com regulação de temperatura TemperatureControl (70º C, 80º C, 90º C e 100º C), apresenta o sistema Keep Warm Function, que mantém a temperatura da água no nível selecionado até 30 minutos, e triplo sistema de segurança - desligar automático ao ferver, proteção contra sobreaquecimento e funcionamento em vazio, e desligamento automático ao levantar a tampa. Outras características: operação com uma mão; abertura da tampa ao toque de um único botão; base interior em aço inoxidável com resistência oculta; sem fio (base com rotação a 360º); filtro anti-calcário amovível em aço inox; indicador de nível de água. </p>

    </div>
     <a href="eira9.php" class="btn btn-primary">Ver
      Mais</a>
  </div>
</div>

                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos eiraui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>