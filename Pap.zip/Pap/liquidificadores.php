<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;


}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 35%;
}

div.card {
  padding: 15px;
  text-align: center;
}

div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.php" >

          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Liquidificadores</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 

        <div class="container" >
          <div class="row">

         
  <div class="card">
    <img class="card-img-top" src="li1.jpg"  ">
    <div class="card-body">
      <h5 class="card-title" >Liquidificador OSTER Pro 1.100  </h5>
      <p class="card-text" >A liquidificadora Oster Pro 1100 BLSTMB-CT0-050 é um equipamento de cozinha elegante e moderno, concebido para preparar sopas, molhos ou deliciosos batidos de fruta, tendo também a capacidade para picar gelo. O jarro de plástico termorresistente apresenta capacidade líquida de 2 litros e contém uma pega e um bocal para poder servir as bebidas à mesa com facilidade. Esta liquidificadora Oster Pro 1100 BLSTMB-CT0-050 com potência máxima de 1100 W possui um sistema de seis lâminas de corte em aço inoxidável, capazes de triturar com rapidez todo o tipo de alimentos. No painel de comandos encontram-se vários botões de pressão que possibilitam selecionar as três velocidades de funcionamento, ativar a função Pulse ou selecionar os três modos pré-programados. Outras características relevantes: motor com funcionamento reversível automático; indicadores luminosos de opções selecionadas; partes amovíveis laváveis na máquina de lavar loiça.</p>

    
    </div>
    <a href="li1.php" class="btn btn-primary">Ver Mais</a>
  </div>


  <div class="card" >
    <img class="card-img-top" src="li2.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Liquidificador KENWOOD SB255 </h5>
      <p class="card-text">A liquidificadora Kenwood SB255 apresenta capacidade de 1,5 litro numa caneca de viagem com sistema antiderramamento, sendo que conta com tampa própria. O SB255 vai fazer uma mistura suficiente para enchê-lo de uma só vez, graças à lâmina de aço inoxidável de alta qualidade, que garante a melhor textura e misturas. Por sua vez, a saída permite uma distribuição mais fácil. Outras características: taça e corpo em plástico; 500 W de potência; pica gelo; armazenamento do cabo; partes laváveis na máquina de lavar louça; torneira dispensadora; pés antideslizantes; sistema de segurança; pá para mexer; duas velocidades + Pulse.</p>
      
      
    </div>
     <a href="li2.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="li3.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Liquidificador BRAUN Jb3060whs </h5>
      <p class="card-text">O liquidificador Braun JB3060WHS, com potência de 800 W e capacidade de 1,75 litro, destaca-se pela tecnologia PowerMax de cinco velocidades mais turbo e pelo jarro à prova de riscos extraível. Também em evidência, o sistema de segurança, a lâmina amovível em aço inoxidável e a tampa doseadora. Outras características: fácil limpeza. Garantia de dois anos.</p>
      
        
    </div>
     <a href="li3.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >


      <div class="row">
   <div class="card">
    <img class="card-img-top" src="li4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Liquidificador BOSCH VitaMais MMB42G0B  </h5>
      <p class="card-text">A liquidificadora Bosch MMB42G0B SilentMixx integra um motor com potência de 700 W altamente eficiente e silencioso. O jarro graduado em vidro ThermoSafe, resistente a altas e baixas temperaturas, com capacidade líquida de 2,3 litros, permite-lhe preparar sopas quentes e batidos gelados. O botão rotativo integrado no corpo da liquidificadora possibilita-lhe selecionar duas velocidades de funcionamento para que controle a espessura dos alimentos, dando-lhe também acesso à função Pulse, para um impulso de potência extra. Destaque também para as lâminas KlickKnife em aço inoxidável, facilmente desmontáveis, fáceis de lavar e com grande precisão para picar, cortar e misturar os alimentos. Todos os plásticos em contacto com os alimentos estão livres de BPA.</p>
      
      
    </div>
     <a href="li4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="li5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Liquidificador KENWOOD SB055 WG  </h5>
      <p class="card-text">O liquidificador Kenwood Smoothie 2Go SB055 de cor branca com apontamentos verde lima é o equipamento ideal para preparar excelentes batidos e sumos de fruta e vegetais, fomentando um estilo de vida saudável e facilitando o consumo das porções ideais de alimentos vegetais no ritmo alucinante do dia-a-dia urbano. Extremamente simples de utilizar, este liquidificador Kenwood Smoothie 2Go SB055 apresenta 300 W de potência, funcionando com duas velocidades selecionadas no painel de controlo de um único botão rotativo. Destaque para a função Pulse, que utiliza a potência máxima do liquidificador para conferir maior intensidade à trituração dos alimentos. Prepare os smoothies de forma prática e rápida e leve-os consigo nas duas canecas de viagem incluídas, para ir bebendo durante o dia. Outras características: lâminas em aço inoxidável amovíveis; permitida utilização como picador de gelo; pés antideslizantes; partes laváveis na máquina de lavar loiça; capacidade do liquidificador de 0,5 litro; sistema de segurança para crianças; arrumador de cabo de alimentação.</p>
      
      
    </div>
     <a href="li5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="li6.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Liquidificador FLAMA 2208FL </h5>
      <p class="card-text">O liquidificador Flama 2208FL, com potência de 400 W e capacidade de 1,25 litro, é o aparelho robusto, simples e potente de que precisa na sua cozinha. O liquidificador Flama 2208FL soma assim duas velocidades a que acresce a função Pulse, para um impulso extra de velocidade e potência que lhe asseguram resultados aprimorados mais rapidamente. Ainda em evidência neste liquidificador Flama 2208FL, o copo em vidro resistente, as lâminas em aço inoxidável e os pés antiderrapantes. Outras características relevantes: enrolador de cabo; fácil limpeza.</p>
      
        
    </div>
     <a href="li6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >
       <div class="row">
  <div class="card" >
    <img class="card-img-top" src="li7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Liquidificador BOSCH Vitamais MMBH6P6B</h5>
      <p class="card-text">
     
O liquidificador Bosch MMBH6P6B conta com um potente motor de 1600 W a mais de 45 mil rotações por minuto que permite processar qualquer tipo de ingrediente de forma rápida. Além disso, soma seis programas automáticos para batidos, sumos, sopas, molhos, gelados e ainda um programa de limpeza. Também em destaque neste liquidificador Bosch MMBH6P6B, o jarro de plástico Tritan duradouro com 2 litros de capacidade, livre de BPA, ideal para processamento de grandes quantidades, e as seis lâminas em aço inoxidável de elevada qualidade, que garantem resultados extrafinos e cremosos, mesmo com alimentos duros e fibrosos. Ainda em evidência no liquidificador Bosch MMBH6P6B, o livro de receitas com mais de 30 receitas de batidos, sumos e muito mais, incluindo conselhos para uma alimentação saudável. Por fim, a velocidade de processamento é a ideal para cada ingrediente, cada bebida e cada ambiente. O controlo de regulação progressiva e uma função Pulse para aquele impulso extra de energia asseguram resultados perfeitos em qualquer altura.

</p>
      
      
    </div>

     <a href="li7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="li8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Liquidificador TRISTAR Blender BL4435  </h5>
      <p class="card-text">Pode preparar batidos ou outras bebidas deliciosas em segundos com este liquidificador Tristar BL4435, que pode levar para qualquer lado. Composto por peças facilmente laváveis, inclui uma tampa removível para a garrafa e um mecanismo para bloqueio da garrafa, bem como pés antiderrapantes. Com capacidade de 0,5 litro e potência de 250 W, destaca-se ainda pelas lâminas amovíveis de aço inoxidável. Outras características: copo pode ser usado como garrafa; sistema de fecho com segurança.</p>
      
      
    </div>
     <a href="li8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="li9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Liquidificador MOULINEX Faciclic Glass LM310E1</h5>
      <p class="card-text">A liquidificadora Moulinex Faciclic Glass LM310E1, com potência de 500 W e capacidade útil de 1,25 litro, destaca-se pelo design robusto e resistente, com suporte anti-derrapamento para facilitar o uso, mas também por características como a função pulsar, que permite maior controlo do processamento, ou pelas suas duas velocidades, não esquecendo a função picar gelo, que lhe permite preparar deliciosos batidos e cocktails. Também em evidência, o copo de vidro graduado e o copo resistente ao choque, bem como a tampa doseadora. Outras características: arrumação integrada do cabo; lâminas em inox amovível; segurança anti-abertura.  </p>

    </div>
     <a href="li9.php" class="btn btn-primary">Ver
      Mais</a>
  </div>

</div>

                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos liui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>