<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;


}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 35%;
}

div.card {
  padding: 15px;
  text-align: center;
}

div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.php" >

          <img src="imagens/m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Ferros de Engomar</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 

        <div class="container" >
          <div class="row">

         
  <div class="card">
    <img class="card-img-top" src="imagens/fe1.jpg"  ">
    <div class="card-body">
      <h5 class="card-title" >Ferro de Engomar Rowenta Pro Master DW8210D1  </h5>
      <p class="card-text" >Desfruta de um engomar rápido e resultados de qualidade profissional com o ferro a vapor DW8210D1 Pro Master da Rowenta. Um potente aparelho de 2800 W com um jato de vapor de 200 gr/min e uma base Microsteam 400 HD Laser patenteada para um engomar com a máxima eficiência. O ferro oferece uma excelente distribuição de vapor, assegurando os melhores resultados. O vapor continuo até 50 gr/min, em conjunto com o super vapor de 200 gr/min, permite retirar facilmente os vincos, em particular nos tecidos mais secos e grossos, e com a ajuda do spray, caso seja necessário. Com um reservatório de 310 ml para uma elevada autonomia em longas sessões de engomar. O modo ECO permite uma poupança de energia até 20% em comparação com o consumo de energia no nível máximo de produção de vapor.</p>

    
    </div>
    <a href="li1.php" class="btn btn-primary">Ver Mais</a>
  </div>


  <div class="card" >
    <img class="card-img-top" src="imagens/fe2.jpg" alt="Card image cap">
    <h1 style='color:#007aff;'><b>|-25%|</b></h1>
    <div class="card-body">
      <h5 class="card-title">Ferro de Engomar Philips GC4567/80 </h5>
      <p class="card-text">Ferro a Vapor GC4567/80 da Philips com potência máxima de 2600 W,para um aqueciemnto rápido e um desempenho potente. Destaca-se pela base SteamGlide Advanced que proporciona um deslizar ultra rápido ao seu engomar e resistente a riscos. Antiaderente, resistente a riscos e fácil de manter limpo.A função de vapor constante expele 50 gramas de vapor por minuto, amaciando a roupa para facilitar a engomagem. Se os tecidos oferecerem demasiada resistência, utilize a função de jato de vapor(220 g/min.)para amolecer a roupa de forma mais eficaz.
Com design inovador este ferro a vapor da Philips consegue facilmente remover as partículas de calcário, e automaticamente são recolhidas no recipiente para calcário amovível.
Outras características importantes são a sua temperatura regulável, o modo de poupança de energia, o sistema anticalcário e antigota.</p>
      
      
    </div>
     <a href="li2.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="imagens/fe3.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Ferro de Engomar Tristar ST-8300 </h5>
      <p class="card-text">Ferro a vapor Tristar ST-8300, com 2000 Watt de potência, permite óptimos resultados.Base em cerâmica resistente e lisa, passa a ferro com facilidade e rapidez.Possui controlo de temperatura contínuo, vapor vertical, função de limpeza automática.

</p>
      
        
    </div>
     <a href="li3.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >


      <div class="row">
   <div class="card">
    <img class="card-img-top" src="imagens/fe4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Ferro de Engomar Philips GC2145/20</h5>
 <p>Ferro de Engomar Philips com 2100 W de potência, capacidade de reservatório de 0.27 L, 110 gr/min de jato de vapor e a base em cerâmica resistente para deslizar facilmente.A ponta tem 3 formas de precisão. Tem uma ponta fina, uma ranhura para botões e um design elegante da extremidade. A nossa ponta de precisão tripla ajuda mesmo nas áreas mais difíceis de engomar, como botões e pregas.
  Este ferro convencional funciona com água da torneira. O calc-clean é uma função de limpeza integrada para remover a acumulação de cálcio ou calcário e manter o melhor desempenho.Sistema antigota
incorporado para evitar os pingos de água na roupa, mesmo quando engoma a baixa temperatura.



</p>   
      
    </div>
     <a href="li4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="imagens/fe5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Ferro de Engomar Braun SI3041GR</h5>
      <p class="card-text">Ferro a Vapor SI3041GR da Braun com potência máxima de 2350 W e depósito de água com capacidade para 0,27 litros, conta com uma placa de cerâmica que evita que se agarre à tua roupa.A função de vapor constante expele 45 gramas de vapor por minuto, enquanto que o jato de vapor é de 140 g/min. Outras características importantes são o sistema anticalcário e antigota. O ferro fica pronto para usar em 35 segundos.</p>
      
      
    </div>
     <a href="li5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="imagens/fe6.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Ferro de Engomar Flama 5386FL 2800W </h5>
      <p class="card-text">BO ferro a vapor 5386FL tem uma potência máxima de 2800W, base cerâmica ULTRA GLIDE, termóstato regulável e sistema anticalcário automático.Com sistema de vapor constante ou vapor vertical, possibilita ainda a regulação do débito de vapor e integra jato de vapor/borrifador.
Podemos ainda destacar as funções AutoClean, Antidrip, Anticalcário e Auto Shut-Off; sinalizador luminoso de funcionamento; depósito de água com capacidade de 365 ml; indicador de nível da água; luz piloto.</p>
      
        
    </div>
     <a href="li6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >
       <div class="row">
  <div class="card" >
    <img class="card-img-top" src="imagens/fe7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Ferro de Engomar Braun SI7062BL</h5>
      <p class="card-text">
     
O SI7062BL da Braun com potência máxima de 2600 W e depósito de água com capacidade para 0,3 litros, destaca-se pela base Eloxal 3D. A função de vapor constante expele 50 gramas de vapor por minuto, enquanto que o jato de vapor é de 225 g/min. Outras características importantes são o sistema anticalcário e antigota.Tecnologia iCare, 3 zonas ativas de vapor, spray de água e dupla proteção contra sobreaquecimento.
</p>
      
      
    </div>

     <a href="li7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="imagens/fe8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Ferro de Engomar Rowenta DX1530D1 2200W  </h5>
      <p class="card-text">Ferro de engomar a vapor Rowenta DX1530D1 , com potência de 2200W e depósito com capacidade de 350 ml, super jato de 100 gr/min e vapor continuo de 30g/min. A função autosteam oferece resultados perfeitos e sem esforço e um débito vapor potente para um engomar com máxima eficiência, rapidez e facilidade.Maior conforto para engomar.Base em aço inoxidável para maior resistência aos riscos e um deslizar mais fácil.
</p>
      
      
    </div>
     <a href="li8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="imagens/fe9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Ferro de Engomar Tristar ST-8132 1000W</h5>
      <p class="card-text">O ferro a vapor de viagem Tristar ST - 8132 tem uma potência máxima de 1000W, base anti aderente, vapor constante de 48 g/min, jato de vapor 68g e Capacidade do tanque 55 ml.Este ferro de passar Bivolt (115/230V), de alça dobrável e bolsa de transporte é a solução ideal para ocupar pouco espaço na bagagem das tua próxima viagem.Com sistema de vapor constante ou vapor vertical, possibilita ainda a regulação do débito de vapor e integra jato de vapor/borrifador.
Podemos ainda destacar a possibilidade de passar com vapor ou a seco e engomar vertical.  </p>

    </div>
     <a href="li9.php" class="btn btn-primary">Ver
      Mais</a>
  </div>

</div>

                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos liui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="imagens/https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>