<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;


}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 35%;
}

div.card {
  padding: 15px;
  text-align: center;
}

div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.php" >

          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Maquinas de Café</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 

          <div class="container">
             <div class="row">

         
  <div class="card">
    <img class="card-img-top" src="cafe1.jpg"  ">
    <div class="card-body">
      <h5 class="card-title" >Máquina de Café Manual BECKEN BECM2493  </h5>
      <p class="card-text" >A máquina de café Becken BECM2493, com potência de 1050 W e pressão de 15 bar, destaca-se pela integração de um bocal de vapor, podendo apresentar diversas funções, entre as quais espumar o leite, preparar cappuccinos com espuma de leite ou preparar qualquer tipo de infusão. A máquina de café Becken BECM2493 evidencia-se também pelo depósito de água com capacidade de 1,5 litro, pela válvula de segurança e pelo reservatório amovível, não esquecendo a bandeja desmontável – aspetos que favorecem e simplificam o processo de limpeza da máquina.O MG23K3515AS da Samsung é um cafe-ondas com grill de comandos eletrónicos e visor digital para rápida e eficaz confeção de refeições. Destaque para a função Grill +30 segundos, que permite gratinar os alimentos obtendo crostas crocantes sem cozinhar em excesso, e para o sistema Keep Warm, que mantém os ingredientes à temperatura adequada. Ainda em evidência, o Quick Defrost, que descongela de forma rápida e equilibrada carne, peixe, aves, vegetais ou pão. O interior em cerâmica é de fácil limpeza, salientando-se ainda a função Eco, que reduz o consumo de energia em stand-by.</p>

    
    </div>
    <a href="cafe1.php" class="btn btn-primary">Ver Mais</a>
  </div>


  <div class="card" >
    <img class="card-img-top" src="cafe2.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina de Café Manual DELONGHI Dedica Style EC785.BG </h5>
      <p class="card-text">A máquina de café manual DeLonghi Dedica EC785.BG de cor bege metálico inclui um calcador de café e um jarro de leite. É especialmente prática e flexível, graças ao Cappuccinatore com rotação 360º e à bandeja dupla que lhe permite preparar diversas bebidas de café e leite, como um latte macchiato, um leite quente ou até um chá. Com sistema de aquecimento Thermoblock e manípulo apto para café em pó (uma ou duas chávenas) e para pastilhas monodose E.S.E., esta máquina inclui também suporte aquecedor de chávenas no topo; painel de controlo intuitivo com três botões iluminados e reservatório de água de 1,1 L.</p>
      
      
    </div>
     <a href="cafe2.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="cafe3.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina de Café KRUPS Nespresso Essenza Mini XN1101P2 </h5>
      <p class="card-text">A máquina de café Nespresso Krups Essenza XN1101P2 de cor branca combina facilidade de utilização, beleza minimalista e qualidade incomparável para criar a experiência suprema em café. Através do conhecimento desenvolvido pelos especialistas de Nespresso e Krups, foi criada a mais pequena máquina de café, feita especialmente para grandes momentos Nespresso. Em destaque nesta máquina de café Nespresso Krups Essenza XN1101P2, o reservatório de água removível de 0,6 litro, a elevada pressão de 19 bar e a personalização de quantidade, não esquecendo o sistema de aquecimento rápido, pronto a utilizar em aproximadamente 25 segundos.</p>
+      
        
    </div>
     <a href="cafe3.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
          <div class="container">
             <div class="row">
  <div class="card" >
    <img class="card-img-top" src="cafe4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina de Café KRUPS Nespresso Inissia XN1005P04   </h5>
      <p class="card-text">Esta máquina Krups tem uma pressão máxima de 19 bares e uma potência de 1260 W. Ao utilizar sistema de cápsulas Nespresso, esta máquina dá uma grande variedade de escolha ao utilizador, podendo escolher entre cafés de fraca, média ou forte intensidade, de todo o mundo, como Colômbia, Brasil ou Etiópia, e com diferentes sabor, como chocolate e avelã. Com um rápido aquecimento, a máquina fica pronta a tirar um café num instante.</p>
      
      
      
    </div>
     <a href="cafe4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="cafe5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina de Café KRUPS Dolce Gusto Mini Me KP123B10 </h5>
      <p class="card-text">Krups Mini Me KP123B. Design da caixa: Independente, Tipo de produto: Máquina espresso. Volume do depósito de água: 0,8 l. Reservatório para café moído: Copo. Tipo de cafeteira: Completamente automático. Número de bicos: 1. Tipo de entrada de café: Cápsula de café. Potência: 1500 W.</p>
      
      
    </div>
     <a href="cafe5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="cafe6.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina de Café KRUPS Dolce Gusto Infinissima KP173BP12</h5>
      <p class="card-text">A máquina de café Infinissima, com design fino e inspirada no símbolo infinito, é a nossa máquina mais surpreendente. Desfrute de infinitas possibilidades de café com facilidade graças a um tanque de água removível de 1.2L e à exclusiva bandeja coletora giratória. Basta colocar a cápsula que escolheu e criar a bebida perfeita com um simples movimento da alavanca. Com a máquina de café Infinissima, você pode criar desde o menor Ristretto 30ml até o nosso maior café XL. Cafés de qualidade pode desfrutar de um café com um creme espesso e aveludado, graças ao sistema de alta pressão. As máquinas são fáceis de usar e limpar. As borras de café permanecem nas cápsulas, facilitando a limpeza da sua máquina.</p>
      
        
    </div>
     <a href="cafe6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
          <div class="container">
             <div class="row">
  <div class="card" >
    <img class="card-img-top" src="cafe7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina de Café Manual KUBO KBECM4842 </h5>
      <p class="card-text">
     
A máquina de café Kubo KBECM4842, com potência de 850 W e pressão de 15 bar, destaca-se pela integração de um bocal de vapor, podendo apresentar diversas funções, entre as quais espumar o leite, preparar cappuccinos com espuma de leite ou preparar qualquer tipo de infusão. A máquina de café Kubo KBECM4842 evidencia-se também pelo depósito de água com capacidade de 1.2 litros, pela válvula de segurança e pelo reservatório amovível, não esquecendo a bandeja desmontável – aspetos que favorecem e simplificam o processo de limpeza da máquina de café Kubo KBECM4842.
Outras características relevantes: indicador de nível de água; Auto Off; colher doseadora. Dimensões (AxLxP): 31.2 x 26.8 x 22.5 cm. Peso de 3.1 kg.
</p>
      
      
    </div>
     <a href="cafe7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="cafe8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina de Café Manual KRUPS XP3440  </h5>
      <p class="card-text">O sistema Termobloco tem 15 bares de pressão. Sendo uma máquina manual, permite um resultado perfeito na chávena exatamente a gosto do utilizador. O porta-filtro para café moído tem capacidade para 1 ou 2 doses. O acessório cappuccino permite tirar o cappuccino perfeito. O depósito de água tem capacidade para 1 L e, tal como a gaveta de recolha de pingos, é amovível. A potência total desta máquina de café Krups é de 1460 W.</p>
      
      
    </div>
     <a href="cafe8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="cafe9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina de Café Manual FLAMA 1266FL</h5>
      <p class="card-text">A máquina de café Expresso, 20 bar com vapor, 1266FL tem uma potência de 1350W, 3 filtros para café moído e unidoses e reservatório com capacidade para 1,2L. Conta ainda com as funções vapor, água quente e cappuccino, tabuleiro apara-gotas, colher doseadora e calcador e superfície para aquecimento de chávenas. Outras características relevantes: indicador de nível de água, sinalizadores luminosos, reservatório amovível transparente e sistema de aquecimento por termobloco. </p>
      
        
    </div>
     <a href="cafe9.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>


                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos cafeui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>