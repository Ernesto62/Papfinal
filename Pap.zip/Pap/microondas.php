<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;


}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 25%;
}

div.card {
  padding: 15px;
  text-align: center;
}

div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.php" >

          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Microondas</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 

          <div class="container">
             <div class="row">

         
  <div class="card">
    <img class="card-img-top" src="micro1.jpg"  ">
    <div class="card-body">
      <h5 class="card-title" >Micro-ondas SAMSUNG MG23K3515AS </h5>
      <p class="card-text" >O MG23K3515AS da Samsung é um micro-ondas com grill de comandos eletrónicos e visor digital para rápida e eficaz confeção de refeições. Destaque para a função Grill +30 segundos, que permite gratinar os alimentos obtendo crostas crocantes sem cozinhar em excesso, e para o sistema Keep Warm, que mantém os ingredientes à temperatura adequada. Ainda em evidência, o Quick Defrost, que descongela de forma rápida e equilibrada carne, peixe, aves, vegetais ou pão. O interior em cerâmica é de fácil limpeza, salientando-se ainda a função Eco, que reduz o consumo de energia em stand-by.</p>

    
    </div>
    <a href="micro1.php" class="btn btn-primary">Ver Mais</a>
  </div>


  <div class="card" >
    <img class="card-img-top" src="micro2.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Micro-ondas SHARP YC-MG5 microador de Cabelo PHILIPS HP8238/10 </h5>
      <p class="card-text">O micro-ondas Sharp YC-MG5, com volume de 25 litros, conta com funcionalidades de grill e com um interior esmaltado, resistente e de fácil limpeza. Além do painel de controlo tátil extremamente intuitivo e do relógio digital, o micro-ondas Sharp YC-MG5 soma 11 níveis de potência e oito programas automáticos, pelo que é muito versátil e capaz de se constituir como um eletrodoméstico fulcral e indispensável na sua cozinha. Também em destaque no micro-ondas Sharp YC-MG5, o modo Eco e o prato rotativo de 315 mm de diâmetro. Outras características: potência de 900 a 1000 W; mostrador; abertura lateral da porta; design plano, fácil de limpar.</p>
      
      
    </div>
     <a href="micro2.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="micro3.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Micro-ondas SAMSUNG GE87M-X </h5>
      <p class="card-text">O micro-ondas Samsung GE87M-X, com volume de 23 litros e 800 W de potência (grill de 1100 W), soma seis níveis de potência e, graças ao modo Eco, economiza até 40% de energia no modo de espera. Pressionando apenas um botão, evita gastos desnecessários de dinheiro e energia, contribuindo para o cuidado com o meio ambiente. Por sua vez, o sistema de distribuição triplo garante que qualquer alimento é perfeitamente preparado graças a três pontos de distribuição de micro-ondas. Já o design espelhado, sofisticado e minimalista, adiciona um toque de estilo à sua cozinha. Por fim, o interior do micro-ondas Samsung GE87M-X é projetado com esmalte de cerâmica para proteger o interior e torná-lo resistente e durável. Deste modo, a limpeza é simples, uma vez que a cerâmica impede que a gordura e o óleo permaneçam nas paredes, bastando passar um pano húmido para que a limpeza seja perfeita. Além disso, é altamente resistente a arranhões. Outras características: visor incorporado; visor LED; relógio digital; proteção para crianças; grelhador; função de descongelação; iluminação interior. 
      
        
    </div>
     <a href="micro3.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container">
             <div class="row">
  <div class="card" >
    <img class="card-img-top" src="micro4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Micro-ondas SHARP YC-MG5  </h5>
      <p class="card-text">O micro-ondas Sharp YC-MG5, com volume de 25 litros, conta com funcionalidades de grill e com um interior esmaltado, resistente e de fácil limpeza. Além do painel de controlo tátil extremamente intuitivo e do relógio digital, o micro-ondas Sharp YC-MG5 soma 11 níveis de potência e oito programas automáticos, pelo que é muito versátil e capaz de se constituir como um eletrodoméstico fulcral e indispensável na sua cozinha. Também em destaque no micro-ondas Sharp YC-MG5, o modo Eco e o prato rotativo de 315 mm de diâmetro. Outras características: potência de 900 a 1000 W; mostrador; abertura lateral da porta; design plano, fácil de limpar.</p>
      
      
    </div>
     <a href="micro4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="micro5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Micro-ondas LG NeoChef MH7265DPS </h5>
      <p class="card-text">O micro-ondas LG MH7265DPS de cor preta, com volume de 32 litros e até 1200 W de potência, apresenta tecnologia Smart Inverter da LG, que fornece uma elevada potência e precisão para aquecer e descongelar uma ampla gama de alimentos de forma mais rápida. Graças ao controlo de temperatura, é possível preparar uma variedade de pratos que anteriormente os micro-ondas não conseguiam cozinhar. Este micro-ondas com Smart Inverter pode adaptar-se consoante os níveis de input de potência, o que significa que pode sempre contar com um constante funcionamento do seu equipamento, mesmo em áreas com baixa tensão, eletricidade limitada ou uma fonte de alimentação de potência mais baixa (300 W no mínimo). O revestimento interior antibacteriano EasyClean torna a limpeza simples e prática. Basta passar com um pano para limpar o interior do micro-ondas. O revestimento elimina 99,99% das bactérias prejudiciais que aderem à superfície. Já o visor LED branco no interior é três vezes mais brilhante e mais eficiente do que as habituais lâmpadas nos modelos convencionais. Esta inovação permite-lhe verificar facilmente o estado dos alimentos sem abrir o seu micro-ondas. Por sua vez, a inovadora base hexagonal estabiliza o prato giratório com seis pontos de apoio, impedindo que os recipientes oscilem ou entornem durante a cozedura. Ao poder ajustar a temperatura para cada tarefa, a carne pode ser uniformemente descongelada, começando no centro e terminando nas extremidades. Além disso, com o micro-ondas LG MH7265DPS é possível fritar, aquecer, assar, descongelar e muito mais - até produzir e fermentar iogurte caseiro. Por fim, a função Fritar Saudável reduz a gordura de todos os pratos até 72% e a função Assar Saudável oferece uma redução de gordura igualmente significativa. Outras características: relógio; definição de hora; bloqueio para crianças; início rápido; prato rotativo.</p>
      
      
    </div>
     <a href="micro5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="micro6.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Micro-ondas LG NeoChef MH6535GDH</h5>
      <p class="card-text">O micro-ondas LG MH6535GDH, com 1000 W de potência e capacidade de 25 litros, apresenta tecnologia Smart Inverter, que fornece elevada potência e precisão para aquecer e descongelar uma ampla gama de alimentos de forma mais rápida. Graças ao controlo de temperatura, é possível preparar uma variedade de pratos que anteriormente os micro-ondas não conseguiam cozinhar. Os micro-ondas LG MH6535GDH com Smart Inverter pode adaptar-se consoante os níveis de input de potência, o que significa que pode sempre contar com um constante funcionamento do seu equipamento, mesmo em áreas com baixa tensão, eletricidade limitada ou uma fonte de alimentação de potência mais baixa (300 W no mínimo). Por sua vez, o revestimento interior antibacteriano EasyClean torna a limpeza simples e prática. Basta passar com um pano para limpar o interior do micro-ondas. O revestimento elimina 99,99% das bactérias prejudiciais que aderem à superfície. Já o visor LED branco no interior é três vezes mais brilhante e mais eficiente do que as habituais lâmpadas nos modelos convencionais. Esta inovação permite-lhe verificar facilmente o estado dos alimentos sem abrir o seu micro-ondas. A inovadora base hexagonal estabiliza o prato giratório com seis pontos de apoio, impedindo que os recipientes oscilem ou entornem durante a cozedura. Por fim, aqueça cada prato a uma temperatura uniforme usando os controlos de temperatura para uma experiência mais saborosa e satisfatória. Outras características: design da porta Hi-T; descongelação uniforme; função Fritar Saudável; função Assar Saudável; modo Iogurteira; relógio; bloqueio para crianças; cobertura de vapor incluída.</p>
      
        
    </div>
     <a href="micro6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container">
             <div class="row">
  <div class="card" >
    <img class="card-img-top" src="micro7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Micro-ondas BECKEN BMW4288 </h5>
      <p class="card-text">
     
O micro-ondas Becken BMW4288, com elevada potência de 900 W, soma 11 níveis de potência em funcionamento e apresenta capacidade de 30 litros. Muito prático e intuitivo, o micro-ondas Becken BMW4288 exibe comandos rotativos, de botão e digitais, nomeadamente para seleção das funções e controlo do temporizador. Também em destaque neste micro-ondas Becken BMW4288, o temporizador de até 95 minutos, o interior esmaltado e o grill convencional, não esquecendo a funcionalidade de descongelação por peso. Outras características relevantes: prato rotativo de 315 mm de diâmetro; iluminação interior; ecrã; relógio; bloqueio de segurança; abertura lateral da porta com pega; forno e grill; prato Crisp (crocante). Dimensões (AxLxP): 30 x 53,9 x 44,6 cm. Peso de 18,4 kg.
</p>
      
      
    </div>
     <a href="micro7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="micro8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Micro-ondas CASO MG 20  </h5>
      <p class="card-text">O micro-ondas Caso MG20 Menu, com volume de 20 litros, apresenta funcionamento eletrónico e uma frente espelhada, sendo extremamente compacto e funcional. A operação é muito intuitiva e os pratos podem ser preparados com grande precisão graças aos 14 programas automáticos. Também em destaque neste micro-ondas Caso MG20 Menu a estrutura em aço inoxidável, o relógio e painel digital eletrónico e o temporizador de até 60 minutos com sinal sonoro. Outras características relevantes: potência de 800 W (micro-ondas) e 1000 W (grill); cinco níveis de potência para aquecimento suave e descongelação; iluminação interior; bloqueio de segurança; prato rotativo de vidro.</p>
      
      
    </div>
     <a href="micro8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="micro9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Micro-ondas SEVERIN  MW7861</h5>
      <p class="card-text">O microador de cabelo Dyson Supersonic conta com um potente motor digital que assegura o controlo inteligente do calor para um brilho natural. Além disso, ajuda a evitar os danos produzidos pelo calor extremo, uma vez que a temperatura é medida 20 vezes por segundo, o que ajuda a mantê-la controlada. Porque microar o cabelo não deveria demorar uma eternidade, o microador de cabelo Dyson Supersonic oferece uma microagem rápida, com fluxo de ar controlado, a alta velocidade. Acresce que a Dyson revolucionou o funcionamento convencional e colocou o motor no manípulo, reequilibrando totalmente o peso e a forma do microador. Por sua vez, o bico concentrador Dyson microa e penteia ao mesmo tempo, usando um fluxo de ar suave e amplo.  Controlado por apenas quatro botões, o microador Dyson Supersonic soma ainda três definições de velocidade de precisão (microagem rápida, microagem normal e modelação) e quatro definições de temperatura de precisão (100° C para microagem e modelagem rápidas, 80° C para microagem normal, 60° C para microagem suave e 28° C para frio constante). Outras características: fácil de limpar; cabo de alimentação profissional com 2,7 metros; acessórios magnéticos; tecnologia Heat Shield (escudo térmico) para superfície fria; potência de 1600 W; bico concentrador fino. </p>
      
        
    </div>
     <a href="micro9.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>


                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos microui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>