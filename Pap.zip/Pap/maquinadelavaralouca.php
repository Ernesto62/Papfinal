<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;


}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 35%;
}

div.card {
  padding: 15px;
  text-align: center;
}

div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.php" >

          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Máquina de Lavar a Loiça</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 

        <div class="container" >
          <div class="row">

         
  <div class="card">
    <img class="card-img-top" src="lou1.jpg"  ">
    <div class="card-body">
      <h5 class="card-title" >Máquina Lavar Loiça Jocel JLL-022967   </h5>
      <p class="card-text" > Com uma eficiência energética D (Nova), esta máquina de lavar louça Jocel com capacidade para 12 conjuntos de talheres conta com 6 programas de lavagem. Com uma potência sonora de 52dB, o seu consumo anual de água é de apenas 3080L, para além disto, conta com diversos sensores de funcionamento, entre eles o indicador de falta de abrilhantador e de sal.</p>

    
    </div>
    <a href="li1.php" class="btn btn-primary">Ver Mais</a>
  </div>


  <div class="card" >
    <img class="card-img-top" src="lou2.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Loiça Indesit DSFE 1B10 C  </h5>
      <p class="card-text">Máquina de lavar loiça Slim com 45 cm de largura, 6 programas, capacidade para 10 conjuntos de talheres e insere-se na classe de eficiência energética F (Nova). Máquina de lavar loiça pequena e compacta, para que possas desfrutar de todo o espaço de que precisas.Com Função de meia carga, projetada para quantidades menores de loiça, para que possas desfrutar de pratos limpos sem teres de esperar para encher a máquina de lavar louça, economizando eletricidade, água e dinheiro.Com Início diferido, o que te permite programar convenientemente o ciclo de lavagem para mais tarde. Simplesmente adiciona o detergente, configura o programa e deixa o aparelho tratar do resto.</p>
      
      
    </div>
     <a href="li2.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="lou3.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Loiça Bosch SMS25AW05E</h5>
      <p class="card-text">Máquina de lavar loiça, em branco, da BOSCH. Classe de eficiência energética e de lavagem E (Nova) e de secagem A. Consumo de água por cada ciclo de 9,5 L e com um consumo anual de 2660 litros. Consumo de energia de 258 kWh por ano e um nível de ruído de 48 dB. Com 5 programas de lavagem distintos, pré programação, programa Eco e opção de meia carga. Como funções extra este fantástico eletrodoméstico incluí um sensor de carga, sensor detetor de sujidade, descalcificador, indicador de sal e de abrilhantador. O sistema AquaStop com garantia vitalícia total contra danos provocados por fugas de água. Graças ao LoadSensor a SMS25AW05E poupa automaticamente água e energia na presença de menos loiça. Também a função EcoSilence DriveTM é uma mais-valia uma vez que aumenta a eficiência de limpeza, sendo bastante potente, silenciosa e eficiente.</p>
      
        
    </div>
     <a href="li3.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >


      <div class="row">
   <div class="card">
    <img class="card-img-top" src="lou4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Loiça Hotpoint-Ariston HFC 3C26 CW X </h5>
 Máquina de lavar a loiça, em inox, da HOTPOINT. De instação livre e com funcionamento silencioso com apenas 46 dB. Classe de eficiência energética E (Nova) e A de secagem. Consumo anual de energia de 265 kWh e de água de 2520 litros. Com sete programas distintos e 4 níveis de temperatura. Dispõe de display disgital, indicador de falta de sal e abrilhantador.    
      
    </div>
     <a href="li4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="lou5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Loiça Bosch SMS4HTW31E</h5>
      <p class="card-text">Máquina de lavar loiça Bosch, com capacidade para 12 conjuntos de talheres conta com 6 programas de lavagem. Com uma potência sonora de 52dB, o seu consumo anual de água é de apenas 3080L, para além disto, conta com diversos sensores de funcionamento, entre eles o indicador de falta de abrilhantador e de sal.</p>
      
      
    </div>
     <a href="li5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="lou6.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Loiça Whirlpool WFC 3C26 P </h5>
      <p class="card-text">Beleza em cada detalhe. As dobradiças grandes garantem uma perfeita harmonia e alinhamento entre o rodapé e a porta decorativa da cozinha.Gestão de espaço ideal. Adicione, remova ou adapte o espaço no interior da sua Máquina de Lavar Loiça como desejar, graças aos cestos modulares e grelhas rebatíveis. À sua medida. A opção Início Diferido permite-lhe programar a Máquina de Lavar Loiça para que dê início ao respetivo ciclo quando for mais conveniente para si, economizando tempo e energia.</p>
      
        
    </div>
     <a href="li6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >
       <div class="row">
  <div class="card" >
    <img class="card-img-top" src="lou7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Loiça Jocel JLLI-022974 IX</h5>
      <p class="card-text">
     
A JLLI-022974 IX da Jocel apresenta capacidade de carga para 14 conjuntos de loiça e insere-se na classe de eficiência energética D (Nova), assegurando um óptimo e económico desempenho. Compacta e elegante, exibe um painel de controlo extremamente simples, onde podes escolher entre os 8 programas de lavagem. Este equipamento tem um consumo energético de 237kWh/ano. Uma potência resistência 1930W, Funcionamento eléctrónico, Filtro em aço inoxidável, Consumo de água 10Lpor ciclo, Função 3 em 1, 3 Cestos e Visor LED.
</p>
      
      
    </div>

     <a href="li7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="lou8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Loiça Bosch SMS25AI05E  </h5>
      <p class="card-text">A SMS25AI05E apresenta capacidade para 12 conjuntos de loiça e insere-se na classe de eficiência energética E (Nova) . Dispõe de uma tecnologia para proteção de vidros, visando um tratamento extra delicado para os copos. O sistema AquaStop evita danos provocados por fugas de água. O LoadSensor faz com que se poupe mais água e energia quando a máquina leva menos loiça. Principal destaque para a pré-seleção do início do programa com a hora desejada. Também a função económica EcoSilence Drive garante o baixo consumo de energia, sendo bastante silenciosa e eficiente. Com a opção VarioSpeedPlus é possível lavar três vezes mais depressa, obtendo óptimos resultados de lavagem e secagem. Esta máquina de lavar a loiça apresenta um consumo anual de água de 2660 litros, sendo que por cada ciclo é de 9.5 litros. Incluí cesto para talheres, suporte para chávenas e copos.</p>
      
      
    </div>
     <a href="li8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="lou9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Loiça Ok ODW 6033 E FS</h5>
      <p class="card-text">Com uma eficiência energética E (Nova), esta máquina de lavar louça Ok com capacidade para 12 conjuntos de talheres conta com 5 programas de lavagem desde o Eco ao Intensivo e 4 temperaturas à escolha e um temporizador integrado. Com uma potência sonora de 49dB, o seu consumo de água por ciclo é de apenas 11L.  </p>

    </div>
     <a href="li9.php" class="btn btn-primary">Ver
      Mais</a>
  </div>

</div>

                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos liui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>