<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;


}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 35%;
}

div.card {
  padding: 15px;
  text-align: center;
}

div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.php" >

          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    
     <main role="main">

     	<div class="container" >

          <div class="row">
            
          
<?php
$con=new mysqli("localhost","root","","eletrodomesticos");
if (isset($_GET['categoria'])) {
	$categoria=$_GET['categoria'];
}
else
	$categoria='aspirador';
if($con->connect_errno!=0){
	echo "Ocorreu um erro no acesso á base de dados".$con->connect_error;
	exit;
}

else{
	if (!isset($_SESSION['login'])){
		$_SESSION['login']="incorreto";
	}
	if ($_SESSION['login']="correto"){
	?>
	
		<a href="eletrodomesticos_create.php">Create</a>
		<h1>Lista de eletrodomesticos</h1>
		<?php
		$sql='select * from eletrodomesticos where categoria=?';

		$stm = $con->prepare($sql);
		if($stm!=false){
			$stm->bind_param('s',$categoria);
			$stm->execute();
			$res=$stm->get_result();
			
			
		}
		else
		{
			echo "<h1>erro</h1>";
			exit;
		}

		
		while($resultado=$res->fetch_assoc()){
      echo '<div class="Col-md-4">';

			echo '<div class="card">';
    
    echo '<img class="card-img-top" src="imagens/'. $resultado['imagem'].'">';
    echo '<div  class="card-body">';
     echo  '<h5 class="card-title" >'.$resultado['eletrodomestico'] .'  </h5>';
      echo  '<p class="card-text" >'.$resultado['descricao'] .'  </p>';
      echo "   </div>";
      echo '<a href="eletro_show.php?eletrodomesticos='.$resultado['id'].'" class="btn btn-primary">Ver Mais</a>';
         echo "   </div>";
         echo "   </div>";

    
 
    
			
			
			//echo '<a href="eletrodomesticos_delete.php?eletrodomesticos='.$resultado['id'].'"> eliminar</a>';
			
			//echo '<a href="eletrodomesticos_edit.php?eletrodomesticos='.$resultado['id'].'"> editar</a>';
			//echo '<br>';
		}
		$stm->close();
		?>

	<?php
}

else{
	echo 'Para entrar nesta página necessita de efetuar <a href="login.php">login</a>';
}
} //end if - if($con->connect_errno!=0)
?>
</div>
</div>


</main>
</body>
</html>