<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width-device-with, initial-scale=1, shrink-to-fit=no">
    <title></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="jumbotrom.css">
   
  <style>
      .navbar a:hover, .dropdown:hover .dropbtn {
  background-color: blue;


}
div.card {
  margin: 5px;
  border: 1px solid #ccc;
  float: left;
  width: 370px;
}

div.card:hover {
  border: 1px solid #007aff;
}

div.card img {
  width: 100%;
  height: 40%;
}

div.card {
  padding: 15px;
  text-align: center;
}

div.card-deck {
  width: 80%;
  height: auto;
          
}
div.menu-footer{
  background: #007aff;
  
}
  </style>
  </head>
  <body>
   <nav class="navbar navbar-expand-md navbar-light fixed-top bg-d" style="background-color: #007aff">
        <a class="navbar-brand" href="index.php" >

          <img src="m.png" >   
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="#navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation"></button>

        <div class="collapse navbar-collapse" id="navbarsExampleDefault">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item active">       
                <a class="nav-link" href="index.php" ><span class="sr-only">(atual)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="produtos.php" style='color:white;'>Produtos</a>

                </li>
                <li class="nav-item">
                    <a class="nav-link desable" href="novidades.php" style='color:white;'>Novidades</a>
                    
                </li>
              
                <li class="nav-item">
                    <a class="nav-link desable" href="promocoes.php" style='color:white;'>Promoções</a>
                    
                </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="login.php" style='color:white;'>Login</a>
                    
                </li>
                 </li>
                <li align="right"
                class="nav-item">
                    <a class="nav-link desable" href="logout.php" style='color:white;'>Logout</a>
                    
                </li>

            </ul>
        </div>
       



        
    </nav>
    <main role="main">
        <br>
       
        <hr>
    </div>
        
       
            <br>
          
          
            
                <h1 class="display-4" style='color:#007aff;' align="center">Máquina de Lavar a Roupa</h1>
        
                 <br>
            <br>
            
                

            </div>
        </div> 

        <div class="container" >
          <div class="row">

         
  <div class="card">
    <img class="card-img-top" src="rou1.jpg"  ">
    <div class="card-body">
      <h5 class="card-title" >Máquina de Lavar Roupa INDESIT MTWA 71252 S WPT  </h5>
      <p class="card-text" >Esta máquina de lavar roupa de carga frontal de livre instalação Indesit tem: uma espaçosa capacidade de 7 kg. Uma velocidade de centrifugação rápida, eficiente em termos de recursos, de 1200 rotações por minuto. O inovador sensor Water Balance Plus é projetado para cortar drasticamente os gastos de água, tempo e energia. Com pequenas cargas, pode economizar até 70% de água e 50% energia, enquanto os ciclos serão 35% mais rápidos.</p>

    
    </div>
    <a href="li1.php" class="btn btn-primary">Ver Mais</a>
  </div>


  <div class="card" >
    <img class="card-img-top" src="rou2.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Roupa Ok OWM 6123 E 6Kg 1200RPM </h5>
      <p class="card-text">A máquina de lavar roupa OWM 6123 E da Ok, com capacidade de carga de 6 kg e velocidade de centrifugação de 1200 RPM, 8 programas de lavagem, para lavagens perfeitas de todos os tipos de tecidos e manchas, bem como diversas outras opções e funções. Equipada com um visor Led, tambor em inox, insere-se na classe de eficiência energética. E (Nova). Tem um consumo de energia por ciclo: 73 kwh e Consumo de água por ciclo: 43 L.</p>
      
      
    </div>
     <a href="li2.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="rou3.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Roupa Bosch WAN24279EP 8Kg 1200RPM </h5>
      <p class="card-text">Máquina de lavar a roupa, em branco, da BOSCH. Classe de eficiência energética C (Nova) e 1200 RPM de velocidade de centrifugação. A opção VarioPerfect permite economizar até 50% de energia. Dispõe de função de recarga, proteção multipla contra inundações e fugas de água. Sistema automático de ajuste de carga e motor EcoSilence com garantia de 10 anos. A WAN24279EP destaca-se pela sua estabilidade e silêncio.</p>
      
        
    </div>
     <a href="li3.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >


      <div class="row">
   <div class="card">
    <img class="card-img-top" src="rou4.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Roupa Samsung WW70T4020EE </h5>
Máquina de lavar a roupa da SAMSUNG WW70T4020EE/EP. Com motor Digital Inverter, capacidade máxima de 7Kg e classe de eficiência energética D. Com 1200 RPM de velocidade de centrifugação e um consumo anual de água de 7400 litros. A tecnologia EcoBubble gera uma espuma suave que penetra ainda mais depressa nos tecidos. Graças a esta tecnologia, conseguirás poupar mais energia e obter melhores resultados de lavagem.     
      
    </div>
     <a href="li4.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="rou5.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Roupa Jocel JLR013880 6Kg 1000RPM</h5>
      <p class="card-text">A JLR013880 da Jocel, com capacidade de carga de 6 kg e velocidade de centrifugação de 1000 RPM, 8 programas de lavagem, para lavagens perfeitas de todos os tipos de tecidos e manchas, bem como diversas outras opções e funções. Equipada com tambor em inox, esta máquina tem uma potência de aquecimento de 1500W e insere-se na classe de eficiência energética.</p>
      
      
    </div>
     <a href="li5.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="rou6.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Roupa Siemens iQ300 WM12N269EP 8Kg 1200RPM </h5>
      <p class="card-text">Máquina de Lavar Roupa Siemens Série iQ300, com Carga Frontal 8 kg, 1200 RPM, motor iQdrive para lavagem especialmente eficiente e eficaz.Programa microfibras + impregnação: lavagem e impermeabilização de tecidos outdoor.Com o passar do tempo, os motores convencionais ficam gastos pela fricção mecânica das escovas de carbono; o motor sem escovas iQdrive não apresenta desgaste. A Siemens garante a durabilidade dos seus motores iQdrive</p.>
      
        
    </div>
     <a href="li6.php" class="btn btn-primary">Ver Mais</a>
  </div>
</div>
<br>
        </div>
           <div class="container" >
       <div class="row">
  <div class="card" >
    <img class="card-img-top" src="rou7.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Roupa Candy CSO 1275TE 1-S 7KG 1200RPM</h5>
      <p class="card-text">
     
 A Candy CSO 1275TE 1-S com capacidade de carga de 7 kg e velocidade de centrifugação de 1200 RPM, insere-se na eficiência energética máxima, classe D (Nova). O seu consumo anual de energia é de 175 kWh e 9600 litros de água ano. A Candy CSO 1275TE 1-S oferece um conjunto completo de ciclos rápidos concebidos para atender às necessidades diárias de lavagem. Esta máquina de lavar roupa está equipada com a tecnologia Simply-Fi, faculta recursos adicionais e exclusivos, como dicas de voz, melhores resultados de eficiência e função remota wifi, para tornar a tarefa de lavagem ainda mais suave e conveniente.
</p>
      
      
    </div>

     <a href="li7.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="rou8.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Roupa Jocel 9KG 1400RPM JLR013941  </h5>
      <p class="card-text">Capacidade de carga de 9 kg e velocidade de centrifugação de 1400 RPM, destaca-se pelos seus 14 programas de lavagem, para lavagens perfeitas de todos os tipos de tecidos e manchas, bem como diversas opções e funções. Equipada com tambor em inox, dupla porta e motor inverter, esta máquina tem uma potência de aquecimento de 2000W e insere-se na classe de eficiência energética A+++.

</p>
      
      
      
    </div>
     <a href="li8.php" class="btn btn-primary">Ver Mais</a>
  </div>
  <div class="card" >
    <img class="card-img-top" src="rou9.jpg" alt="Card image cap">
    <div class="card-body">
      <h5 class="card-title">Máquina Lavar Roupa Candy HCU1210TXMRRES</h5>
      <p class="card-text"> A Candy HCU1210TXMRRES  com capacidade de carga de 10 kg e velocidade de centrifugação de 1400 RPM, insere-se na eficiência energética máxima, classe A (Nova). O seu consumo anual de energia é de 192 kWh e 12100 litros de água.A Candy HCU1210TXMRRES dispõe de início diferido, seleção de temperatura e de centrifugação. Com display digital, teclas soft touch e indicadores luminosos.A Candy HCU1210TXMRRES vem equipada com tecnologia Mix Power Jet+; Motor Inverter -Inverter Smart System .
    </div>
     <a href="li9.php" class="btn btn-primary">Ver
      Mais</a>
  </div>

</div>

                                    
<br>
<br>



    <p>&copy;Companhia GPSI 2020-2021</p></footer>
    <div class="menu-footer">
      <div class="row">
      <div class="col-sm-8 column-menu column">
        <div class="row"><div class="col-sm-3 column"><p class="title-menu">Euronics</p>
          <ul><li><a href="//www.euronics.pt/pt/euronics/quem-somos_278.html">Quem somos</a></li><li><a href="//www.euronics.pt/pt/euronics/as-nossas-lojas_280.html">As Nossas Lojas</a></li>
            <li><a href="//www.euronics.pt/pt/euronics/contactos_281.html">Contactos</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Explore</p><ul>
              <li><a href="//www.euronics.pt/pt/explore/glossario_839.html">Glossário</a></li>
              <li><a href="//www.euronics.pt/pt/explore/cartao-euronics_285.html">Cartão Euronics</a></li><li><a href="//www.euronics.pt/pt/explore/guia-medidas-certas_838.html">Guia medidas certas</a></li></ul></div>
            <div class="col-sm-3 column"><p class="title-menu">Serviços</p><ul>
              <li><a href="//www.euronics.pt/pt/servicos/assistencia-pos-venda_289.html">Assistência Pós-Venda</a></li><li><a href="//www.euronics.pt/pt/servicos/entregas-euronics_290.html">Entregas Euronics</a></li>
              <li><a href="//www.euronics.pt/pt/servicos/servicos-instalacao_291.html">Serviços instalação</a></li></ul></div>
              <div class="col-sm-3 column">
                <p class="title-menu">Ajuda Euronics</p><ul>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/a-sua-encomenda_1103.html">A sua encomenda</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/perguntas-frequentes_295.html">Perguntas Frequentes</a></li>
                  <li><a href="//www.euronics.pt/pt/ajuda-euronics/trocas-e-devolucoes_298.html">Trocas e Devoluções</a></li></ul></div></div></div><div class="col-sm-4 column-help"><p class="title-menu">Apoio ao cliente</p><div class="row"><div class="col-sm-6 column">
                    <p class="h4 phone">22 605 78 28  </p>
                    <p>9:30 ÀS 13H00 - 14H30 ÀS 19:00 (WET) <br>DIAS ÚTEIS</p></div>

<div class="col-sm-6 column">
  <p class="h4 chat">Chat Online </p><p>Fale connosco, estamos liui</p></div>
  <div class="col-sm-6 column"><a href="//www.euronics.pt/pt/euronics/contactos_281.html" class="h4 message">Contacte-nos</a><p>Envie-nos a sua opinião ou questão</p></div><div class="col-sm-6 column">
  <p class="h4"></p><p class="livro_rec" style="margin-left: 15%;"><a href="https://www.livroreclamacoes.pt/inicio" target="_blank"><img src="https://1194277813.rsc.cdn77.org/sysimages/icon_livro.png" alt=" " title=" "></a></p></div></div></div></div></div>


    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

    </main>
  </body>
</html>